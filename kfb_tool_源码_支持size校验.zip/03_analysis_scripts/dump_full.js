#!/usr/bin/env node
'use strict';
// Walk the decoded AST to an object path and print its full field sequence
// (known + unknown merged by offset), including nested base blocks.
const fs = require('node:fs');
const decoder = require('../01_tools/kfb_schema_decoder.js');

const SCHEMA = __dirname + '/../01_tools/kfb_schema.json';
const schema = decoder.normalizeSchema(JSON.parse(fs.readFileSync(SCHEMA, 'utf8')));

const file = process.argv[2];
const wantPath = process.argv[3];
const buffer = fs.readFileSync(file);
const result = decoder.decodeKfb(buffer, schema, { lenientUnknown: true });

// index unknown fields by their parent objectPath (path minus last component)
const unknownByParent = new Map();
for (const u of result.unknownFields) {
  const idx = u.objectPath.lastIndexOf('.');
  const parent = u.objectPath.slice(0, idx);
  if (!unknownByParent.has(parent)) unknownByParent.set(parent, []);
  unknownByParent.get(parent).push(u);
}

function selectIndex(target, idx, rest, path, comp) {
  // target is a list/array/dictionary ast; idx selects an item/entry
  if (target.kind === 'dictionary') {
    const entry = target.entries[idx];
    const slot = rest[0];
    const slotTarget = slot === 'Key' ? entry.key : entry.value;
    return { node: slotTarget, rest: rest.slice(1) };
  }
  const items = target.items || [];
  return { node: items[idx], rest };
}

function walk(node, comps, path) {
  if (!node) return;
  if (comps.length === 0) { printObject(node, path); return; }
  const comp = comps[0];
  const m = comp.match(/^([^\[]+)(?:\[(\d+)\])?$/);
  const name = m[1];
  const idx = m[2] !== undefined ? parseInt(m[2], 10) : null;
  const rest = comps.slice(1);
  if (node.kind === 'object') {
    const f = (node.fields || []).find((x) => x.name === name || x.name.toLowerCase() === name.toLowerCase());
    if (!f) { console.log('MISS field', name, 'in', node.type, 'have:', (node.fields || []).map((x) => x.name).join(',')); return; }
    if (idx === null) {
      walk(f.value, rest, path + '.' + comp);
    } else {
      const picked = selectIndex(f.value, idx, rest, path, comp);
      walk(picked.node, picked.rest, path + '.' + comp + (picked.rest.length !== rest.length ? '.' + rest[0] : ''));
    }
  } else if (node.value !== undefined) {
    walk(node.value, comps, path);
  } else {
    console.log('UNHANDLED node kind', node.kind, 'at', path, 'comps:', comps.join('.'));
  }
}

function printObject(obj, path) {
  console.log(`\n=== ${obj.type} @ ${path} (offset ${obj.offset}) ===`);
  const unknowns = (unknownByParent.get(path) || []).slice().sort((a, b) => a.offset - b.offset);
  const rows = [];
  for (const f of obj.fields || []) {
    rows.push({ offset: f.offset, tag: f.tag, wire: f.wireName, by: f.declaredBy, name: f.name, val: summarize(f.value) });
  }
  for (const u of unknowns) {
    rows.push({ offset: u.offset, tag: u.tag, wire: u.wireName + '*', by: u.declaringType + ' *UNKNOWN*', name: `tag_${u.tag}`, val: JSON.stringify(u.value).slice(0, 40) });
  }
  if (!process.env.NOSORT) rows.sort((a, b) => a.offset - b.offset);
  for (const r of rows) {
    console.log(`  @${String(r.offset).padStart(6)} tag ${String(r.tag).padStart(3)} ${String(r.wire).padEnd(8)} ${String(r.by).padEnd(45)} ${String(r.name).padEnd(28)} = ${r.val}`);
  }
}

function summarize(v) {
  if (v === null || v === undefined) return String(v);
  if (typeof v !== 'object') return JSON.stringify(v);
  if (v.kind === 'object') return `{object ${v.type} @${v.offset}}`;
  if (v.kind === 'list' || v.kind === 'array') return `[list len=${(v.items || []).length}]`;
  if (v.kind === 'dictionary') return `{dict len=${(v.entries || []).length}}`;
  if (v.semantic !== undefined) return JSON.stringify(v.semantic).slice(0, 50);
  return JSON.stringify(v).slice(0, 50);
}

const comps = wantPath.split('.').filter((c) => c !== '$');
walk(result.ast, comps, '$');
