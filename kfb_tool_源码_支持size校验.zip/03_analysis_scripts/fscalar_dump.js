#!/usr/bin/env node
'use strict';
// Dump every custom (wire-3) sub-block for FScalar fields in a KFB, with hex + offsets.
const fs = require('node:fs');
const decoder = require('../01_tools/kfb_schema_decoder.js');

const SCHEMA = __dirname + '/../01_tools/kfb_schema.json';
const schema = decoder.normalizeSchema(JSON.parse(fs.readFileSync(SCHEMA, 'utf8')));

const file = process.argv[2];
const buffer = fs.readFileSync(file);
const result = decoder.decodeKfb(buffer, schema, { lenientUnknown: true });

// unknownFields carries custom-leftover entries: value = "leftover:hex"
let shown = 0;
for (const u of result.unknownFields) {
  if (String(u.value).startsWith('leftover:')) {
    const hex = String(u.value).slice('leftover:'.length);
    console.log(`${u.objectPath}  offset=${u.offset}  leftover=${hex}`);
    if (++shown > 12) break;
  }
}
console.log(`total unknown: ${result.unknownFields.length}`);
