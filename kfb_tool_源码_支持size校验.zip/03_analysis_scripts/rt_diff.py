#!/usr/bin/env python3
"""Compare two KFB files field-by-field (presence + values) to debug byte-level round-trip.

Uses the JS decoder twice per file: once with the real schema (values + defaults
filled) and once with a defaults-stripped schema (presence only). Then walks both
semantic trees in lockstep and reports:
  - fields present in A but not B (extra)
  - fields present in B but not A (missing)
  - fields present in both with different values
Usage: python3 rt_diff.py <a.kfb> <b.kfb> [--schema path] [--limit N]
"""
import json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.join(HERE, '..', '01_tools')

JS = r'''
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const decoder = require(path.join(process.argv[2], 'kfb_schema_decoder.js'));
const schemaPath = process.argv[3];
const kfbPath = process.argv[4];
const strip = process.argv[5] === 'strip';
let raw = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
if (strip) {
  for (const t of raw.types) { delete t.default_json; }
}
const schema = decoder.normalizeSchema(raw);
const buf = fs.readFileSync(kfbPath);
const result = decoder.decodeKfb(buf, schema);
process.stdout.write(JSON.stringify(result.semantic));
'''

def decode(kfb, schema, strip):
    with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False) as f:
        f.write(JS)
        script = f.name
    try:
        out = subprocess.run(['node', script, TOOLS, schema, kfb, 'strip' if strip else 'keep'],
                             capture_output=True, text=True, check=True)
        return json.loads(out.stdout)
    finally:
        os.unlink(script)

def flat(o, prefix, out):
    if isinstance(o, dict):
        # type marker: '$type' style keys are handled by ordering only
        for k, v in o.items():
            p = f'{prefix}.{k}' if prefix else k
            if isinstance(v, (dict, list)):
                flat(v, p, out)
            else:
                out[p] = v
    elif isinstance(o, list):
        for i, v in enumerate(o):
            p = f'{prefix}[{i}]'
            if isinstance(v, (dict, list)):
                flat(v, p, out)
            else:
                out[p] = v

def main():
    a_path, b_path = sys.argv[1], sys.argv[2]
    schema = (os.path.join(TOOLS, 'kfb_schema.json'))
    if '--schema' in sys.argv:
        schema = sys.argv[sys.argv.index('--schema') + 1]
    limit = int(sys.argv[sys.argv.index('--limit') + 1]) if '--limit' in sys.argv else 40

    a_pres = decode(a_path, schema, True)
    b_pres = decode(b_path, schema, True)
    a_val = decode(a_path, schema, False)
    b_val = decode(b_path, schema, False)

    fa, fb = {}, {}
    flat(a_pres, '', fa)
    flat(b_pres, '', fb)
    va, vb = {}, {}
    flat(a_val, '', va)
    flat(b_val, '', vb)

    keys = sorted(set(fa) | set(fb))
    extra = [k for k in keys if k in fa and k not in fb]
    missing = [k for k in keys if k in fb and k not in fa]
    vdiff = [k for k in keys if k in fa and k in fb and va.get(k) != vb.get(k)]
    print(f'A={a_path} ({len(fa)} present leaves), B={b_path} ({len(fb)} present leaves)')
    print(f'extra in A (game wrote, we omitted): {len(extra)}')
    print(f'extra in B (we wrote, game omitted): {len(missing)}')
    print(f'value diffs: {len(vdiff)}')
    print()
    def show(label, items):
        print(f'--- {label} (first {limit}) ---')
        for k in items[:limit]:
            av = va.get(k, '<absent>')
            bv = vb.get(k, '<absent>')
            print(f'  {k}\n     A={json.dumps(av)[:120]}\n     B={json.dumps(bv)[:120]}')
        if len(items) > limit:
            print(f'  ... and {len(items) - limit} more')
        print()
    show('EXTRA IN A', extra)
    show('EXTRA IN B', missing)
    show('VALUE DIFF', vdiff)

if __name__ == '__main__':
    main()
