#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
"""Show schema entries (own fields with tags) for given classes."""
import json, sys

SCHEMA = os.path.join(HERE, '../01_tools/kfb_schema.json')
schema = json.load(open(SCHEMA, encoding='utf-8'))
types = {t['full_name']: t for t in schema['types']}

for cls in sys.argv[1:]:
    t = types.get(cls)
    print(f'=== {cls} (type_id={t.get("type_id") if t else None}, base={t.get("base_type") if t else None}) ===')
    if not t:
        print('  (not in schema)')
    else:
        for f in sorted(t['fields'], key=lambda x: x['tag']):
            print(f"  tag {f['tag']:>4}  {f['name']:<38} {f.get('field_type','')}")
    print()
