#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Verify new-field runtime values across the three runtime JSON dumps."""
import json, re, sys, os
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
FILES = {n: os.path.join(HERE, f'../02_samples/runtime_exports/新{n}.json') for n in ['90059', '90097', '90381']}

FIELD_RE = re.compile(r'^(?P<type>.+?) (?P<name>[^ @]+) @0x[0-9A-Fa-f]+$')

def collect(cls_short, fields):
    """Walk runtime JSON; find dict wrappers named <...cls_short>; count values of given fields."""
    counts = {f: Counter() for f in fields}
    seen = 0
    def walk(node):
        nonlocal seen
        if isinstance(node, dict):
            for k, v in node.items():
                short = k.split('.')[-1] if '.' in k else k
                if isinstance(v, dict) and short == cls_short:
                    seen += 1
                    for fk, fv in v.items():
                        m = FIELD_RE.match(fk)
                        if m and m.group('name') in counts:
                            counts[m.group('name')][repr(fv)] += 1
                walk(v)
        elif isinstance(node, list):
            for item in node:
                walk(item)
    for path in FILES.values():
        data = json.load(open(path, encoding='utf-8'))
        walk(data)
    print(f'=== {cls_short} instances={seen} ===')
    for f in fields:
        total = sum(counts[f].values())
        top = counts[f].most_common(4)
        print(f'  {f}: present={total}/{seen} values={top}')

collect('KHScriptData', ['key', 'motionFrameIndex', 'scriptIndex'])
collect('ChangeTargetArg', ['checkBorder', 'recursiveFindObjectFrame', 'objectFrameIndex'])
collect('TSHitTestArg', ['recursiveFindObjectFrame', 'hurtBuffIdList', 'objectFrameIndex', 'hurtBuffIdStr'])
collect('SetSkillCircleCursorArg', ['rockerIconPath', 'isFollowRotation', 'radius', 'setSubCirclelst'])
collect('MoveActorScriptArg', ['immediately', 'useAttackBoxParams'])
collect('AOEScriptArg', ['recursiveFindObjectFrame', 'name', 'stop', 'durationFrame', 'continuousKeepType',
                         'leaveAoeExtraArg', 'isContinuous', 'aoeAllowItemDetect', 'useAttackBoxParams'])
collect('SearchElementWithSSTypeArg', [])  # wrapper check only
collect('KFLBoolParameterInfo', ['AssignStyle'])
