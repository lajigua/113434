#!/usr/bin/env node
'use strict';
// Lenient-scan new-version KFB files and report every unknown (class, tag, wire) occurrence.
const fs = require('node:fs');
const decoder = require('../01_tools/kfb_schema_decoder.js');

const SCHEMA = __dirname + '/../01_tools/kfb_schema.json';
const schema = decoder.normalizeSchema(JSON.parse(fs.readFileSync(SCHEMA, 'utf8')));

const files = process.argv.slice(2);
const summary = new Map(); // key: `${declaringType}|${tag}|${wire}` -> { count, samples, paths }
for (const file of files) {
  const buffer = fs.readFileSync(file);
  try {
    const result = decoder.decodeKfb(buffer, schema, { lenientUnknown: true });
    console.log(`\n### ${file}: decoded OK, ${result.unknownFields.length} unknown field occurrences`);
    for (const u of result.unknownFields) {
      const key = `${u.declaringType}|tag ${u.tag}|wire ${u.wire} (${u.wireName})`;
      if (!summary.has(key)) summary.set(key, { count: 0, samples: new Set(), paths: new Set() });
      const entry = summary.get(key);
      entry.count += 1;
      if (entry.samples.size < 5) entry.samples.add(String(u.value));
      if (entry.paths.size < 3) entry.paths.add(u.objectPath);
    }
  } catch (error) {
    console.log(`\n### ${file}: FAILED -> ${error.message}`);
  }
}
console.log('\n========== SUMMARY ==========');
for (const [key, entry] of [...summary.entries()].sort()) {
  console.log(`${key}`);
  console.log(`  count=${entry.count} samples=[${[...entry.samples].join(', ')}]`);
  console.log(`  example paths: ${[...entry.paths].join(' ; ')}`);
}
if (summary.size === 0) console.log('(no unknown fields)');
