#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
"""Compare old kfb_schema.json fields vs dump.cs field declarations (line-scan parser)."""
import json, re, sys

SCHEMA = os.path.join(HERE, '../01_tools/kfb_schema.json')
DUMP = 'os.path.join(HERE, '../04_reverse/dump.cs')'

schema = json.load(open(SCHEMA, encoding='utf-8'))
lines = open(DUMP, encoding='utf-8').read().splitlines()

# Build index: full class name -> (start_line, bases)
CLASS_RE = re.compile(r'^(?:public|private|internal|protected)(?: sealed| abstract)? (?:class|struct) ([\w.<>`\[\],]+?)(?:<[^>]*>)?(?: : (.*))?$')
class_index = {}
for idx, line in enumerate(lines):
    m = CLASS_RE.match(line)
    if m:
        class_index.setdefault(m.group(1), (idx, m.group(2) or ''))

FIELD_RE = re.compile(r'^\tpublic (?:const )?([\w.<>\[\], ]+?) (\w+);(?: // 0x([0-9a-fA-F]+))?')
METHOD_RE = re.compile(r'^\t.*?(ReadField|WriteField)\((?:.*?)\); // 0x([0-9A-Fa-f]+)')

def dump_class_block(cls_full):
    if cls_full not in class_index:
        return None, None, None
    start, bases = class_index[cls_full]
    fields, methods = [], {}
    for idx in range(start + 1, min(start + 4000, len(lines))):
        line = lines[idx]
        if not line.startswith('\t'):
            break  # next class / namespace comment
        fm = FIELD_RE.match(line)
        if fm:
            ftype, fname, off = fm.group(1), fm.group(2), fm.group(3)
            fields.append((ftype, fname, int(off, 16) if off else 0))
            continue
        mm = METHOD_RE.match(line)
        if mm:
            methods[mm.group(1)] = int(mm.group(2), 16)
            continue
        if line.startswith('\t//') or line.startswith('\tprivate') or line.startswith('\tinternal') or line.startswith('\tprotected'):
            continue
    return fields, bases, methods

def schema_type(cls):
    for t in schema['types']:
        if t['full_name'] == cls:
            return t
    return None

for cls in sys.argv[1:]:
    t = schema_type(cls)
    dfields, bases, methods = dump_class_block(cls)
    if t is None or dfields is None:
        print(f'!! {cls}: not found (schema={t is not None}, dump={dfields is not None})')
        continue
    own = [(f['tag'], f['name'], f['field_type']) for f in t['fields'] if f.get('declared_by') == cls]
    own_names = {f[1] for f in own}
    dump_own = [(ft, fn, off) for ft, fn, off in dfields if not fn.isupper() and 'k__' not in fn]
    dump_names = {fn for _, fn, _ in dump_own}
    missing = [(ft, fn, off) for ft, fn, off in dump_own if fn not in own_names]
    removed = [(tag, name) for tag, name, ft in own if name not in dump_names]
    print(f'=== {cls} (type_id={t.get("type_id")}, schema base={t.get("base_type")}, dump base={bases[:70]}) ===')
    print(f'  schema own: {len(own)}  dump own: {len(dump_own)}  max_schema_tag={max((f[0] for f in own), default=0)}')
    if missing:
        print('  NEW fields missing from schema (dump declaration order):')
        for ft, fn, off in missing:
            print(f'    {fn:<32} {ft:<58} @0x{off:x}')
    if removed:
        print('  in schema but not in dump:', removed)
    if methods:
        print('  methods: ' + ', '.join(f'{k}@0x{v:x}' for k, v in methods.items()))
    print()
