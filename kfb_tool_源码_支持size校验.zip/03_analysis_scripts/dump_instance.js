#!/usr/bin/env node
'use strict';
// Dump raw hex around unknown-field occurrences for one declaring type to inspect tag layout.
const fs = require('node:fs');
const decoder = require('../01_tools/kfb_schema_decoder.js');

const SCHEMA = __dirname + '/../01_tools/kfb_schema.json';
const schema = decoder.normalizeSchema(JSON.parse(fs.readFileSync(SCHEMA, 'utf8')));

const file = process.argv[2];
const wantType = process.argv[3] || 'KH.AOEScriptArg';
const buffer = fs.readFileSync(file);
const result = decoder.decodeKfb(buffer, schema, { lenientUnknown: true });

const unknowns = result.unknownFields.filter((u) => u.declaringType === wantType);
console.log(`${file}: ${unknowns.length} unknowns for ${wantType}`);
if (unknowns.length === 0) process.exit(0);
const first = unknowns[0];
console.log('first path:', first.objectPath);
// print all unknowns of this instance path sorted by offset
const instanceUnknowns = unknowns.filter((u) => u.objectPath === first.objectPath).sort((a, b) => a.offset - b.offset);
console.log('instance unknowns by offset:');
for (const u of instanceUnknowns) {
  console.log(`  offset ${u.offset} tag ${u.tag} wire ${u.wire} ${u.wireName} value=${JSON.stringify(u.value).slice(0, 60)}`);
}
// hexdump a window covering them
const minOff = Math.max(0, instanceUnknowns[0].offset - 48);
const maxOff = instanceUnknowns[instanceUnknowns.length - 1].offset + 64;
const hex = buffer.subarray(minOff, maxOff).toString('hex');
console.log(`\nhex ${minOff}..${maxOff}:`);
for (let i = 0; i < hex.length; i += 32) console.log(`  ${(minOff + i / 2).toString(16).padStart(5, '0')}: ${hex.slice(i, i + 32)}`);
