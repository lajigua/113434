#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
"""Scan runtime-readable JSON dumps, rebuild class -> field sets, compare with old schema."""
import json, re, sys
from collections import defaultdict

FIELD_RE = re.compile(r'^(?P<type>.+?) (?P<name>[A-Za-z_][A-Za-z0-9_<>.]*) @0x[0-9A-Fa-f]+$')

def scan(node, class_fields, prefix='', max_depth=0):
    if max_depth > 50:
        return
    if isinstance(node, dict):
        for k, v in node.items():
            m = FIELD_RE.match(k)
            if m:
                ftype = m.group('type')
                fname = m.group('name')
                # type like "KH.AnimationClipData" or "List<KH.AnimationBoxData.AttackBox>" or "FVector3"
                base = ftype
                if base.startswith('List<') and base.endswith('>'):
                    base = base[5:-1]
                if base.startswith('Dictionary<') and base.endswith('>'):
                    base = base[11:-1]
                    base = base.split(',', 1)[-1].strip()
                if base.startswith('Entry<'):
                    base = base[6:-1]
                    parts = base.split(',', 1)
                    base = parts[-1].strip() if parts else base
                    base = base.replace('[]', '')
                # the child dict itself (if v is dict) describes class 'base'
                if isinstance(v, dict):
                    child_class = base
                    # collect field names of child_class from v's keys
                    for ck in v.keys():
                        cm = FIELD_RE.match(ck)
                        if cm:
                            class_fields[child_class].add(cm.group('name'))
                    scan(v, class_fields, max_depth + 1)
                else:
                    scan(v, class_fields, max_depth + 1)
            else:
                # keys like "KH.AnimationClipData" (type wrapper), "Entry<...>[]" etc
                if isinstance(v, (dict, list)):
                    scan(v, class_fields, max_depth + 1)
    elif isinstance(node, list):
        for item in node:
            scan(item, class_fields, max_depth + 1)

def norm(t):
    t = t.strip()
    for pre, suf in [('List<','>'), ('Dictionary<','>')]:
        if t.startswith(pre) and t.endswith(suf):
            inner = t[len(pre):-1]
            return norm(inner.split(',')[-1] if pre=='Dictionary<' else inner)
    if t.startswith('Entry<') and t.endswith('>'):
        return norm(t[6:-1].split(',')[-1])
    return t.replace('[]','')

def main():
    class_fields = defaultdict(set)
    for name in ['90059', '90097', '90381']:
        data = json.load(open(os.path.join(HERE, f'../02_samples/runtime_exports/新{name}.json')))
        scan(data, class_fields)
    print(f'classes found in runtime dumps: {len(class_fields)}')

    schema = json.load(open('os.path.join(HERE, '../01_tools/kfb_schema.json')'))
    schema_by_name = {}
    for t in schema['types']:
        schema_by_name[t['full_name']] = t

    # compare
    new_classes = []
    new_fields = []
    for cname, fields in sorted(class_fields.items()):
        ckey = cname
        st = schema_by_name.get(ckey)
        if st is None:
            # try alias: e.g. FVector3 -> KH.FVector3
            for cand in (f'KH.{cname}', f'Morefun.LockStep.{cname}', f'UnityEngine.{cname}'):
                if cand in schema_by_name:
                    st = schema_by_name[cand]
                    ckey = cand
                    break
        if st is None:
            new_classes.append((cname, sorted(fields)))
            continue
        old_fields = {f['name'] for f in st['fields']}
        extra = fields - old_fields
        if extra:
            new_fields.append((ckey, sorted(extra), sorted(old_fields)))

    print('\n=== NEW CLASSES (not in old schema) ===')
    for c, fs in new_classes:
        print(f'  {c}: {fs}')
    print('\n=== CLASSES WITH NEW FIELDS ===')
    for c, extra, old in new_fields:
        print(f'  {c}: +{extra}')
        print(f'      old: {old}')

if __name__ == '__main__':
    main()
