#!/usr/bin/env node
'use strict';
// List AST object nodes whose offset falls in [start, end), with fields.
const fs = require('node:fs');
const decoder = require('../01_tools/kfb_schema_decoder.js');
const SCHEMA = __dirname + '/../01_tools/kfb_schema.json';
const schema = decoder.normalizeSchema(JSON.parse(fs.readFileSync(SCHEMA, 'utf8')));

const file = process.argv[2];
const start = parseInt(process.argv[3], 10);
const end = parseInt(process.argv[4], 10);
const buffer = fs.readFileSync(file);
const result = decoder.decodeKfb(buffer, schema, { lenientUnknown: true });

function walk(node, path) {
  if (!node || typeof node !== 'object') return;
  if (node.kind === 'object' && node.offset !== undefined && node.offset >= start && node.offset < end) {
    console.log(`\n=== ${node.type} @ ${path} (offset ${node.offset}..${node.endOffset}) ===`);
    for (const f of node.fields || []) {
      const v = f.value && f.value.semantic !== undefined ? JSON.stringify(f.value.semantic).slice(0, 60) : (f.value ? f.value.kind : '');
      console.log(`  @${f.offset} tag ${f.tag} ${f.wireName.padEnd(8)} ${String(f.declaredBy).split('.').pop()}.${f.name} = ${v}`);
    }
  }
  for (const key of Object.keys(node)) {
    const v = node[key];
    if (Array.isArray(v)) v.forEach((c, i) => walk(c, `${path}.${key}[${i}]`));
    else if (v && typeof v === 'object' && v.kind) walk(v, `${path}.${key}`);
  }
}
walk(result.ast, '$');
for (const u of result.unknownFields) {
  if (u.offset >= start && u.offset < end) console.log(`  UNKNOWN @${u.offset} ${u.declaringType} tag ${u.tag} wire ${u.wireName} = ${String(u.value).slice(0, 50)}`);
}
