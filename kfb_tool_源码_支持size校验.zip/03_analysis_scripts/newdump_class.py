#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
"""Extract class blocks (fields + method RVAs) from the NEW dump.cs."""
import re, sys

DUMP = os.path.join(HERE, '../04_reverse/dump.cs')

lines = open(DUMP, encoding='utf-8').read().splitlines()

CLASS_RE = re.compile(r'^(?:public|private|internal|protected)(?: sealed| abstract)? (?:class|struct) ([\w.<>`\[\],]+?)(?:<[^>]*>)?(?: : (.*))?$')
FIELD_RE = re.compile(r'^\t(?:public|private|protected|internal) (?:static )?(?:const )?([\w.<>\[\], ]+?) (\w+);(?: // 0x([0-9a-fA-F]+))?')
METHOD_RE = re.compile(r'^\t.*?(ReadField|WriteField)\((.*?)\); // 0x([0-9A-Fa-f]+)')

class_index = {}
for idx, line in enumerate(lines):
    m = CLASS_RE.match(line)
    if m:
        class_index.setdefault(m.group(1), (idx, m.group(2) or ''))

def dump_class(cls_full):
    if cls_full not in class_index:
        print(f'!! {cls_full}: class not found in dump.cs')
        return
    start, bases = class_index[cls_full]
    print(f'=== {cls_full} (base: {bases}) ===')
    for idx in range(start + 1, min(start + 4000, len(lines))):
        line = lines[idx]
        if not line.startswith('\t'):
            if line.strip() in ('{', '}', ''):
                continue
            break
        fm = FIELD_RE.match(line)
        if fm:
            off = fm.group(3)
            print(f'  field {fm.group(2):<36} {fm.group(1):<60} @0x{off}' if off else f'  field {fm.group(2):<36} {fm.group(1)}')
            continue
        mm = METHOD_RE.match(line)
        if mm:
            print(f'  method {mm.group(1)}({mm.group(2)}) @0x{mm.group(3)}')
            continue
    print()

for cls in sys.argv[1:]:
    dump_class(cls)
