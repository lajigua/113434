#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Parse capstone disassembly text of KFB WriteField methods; extract (obj-offset, tag, kind)."""
import re, sys

# call targets identified from wf_subcircle cross-analysis
CALL_HEADER = '0x5b40034'   # writer.WriteHeader(tag, wire)  (w1=tag, w2=wire)
CALL_FSCALAR = '0x483a318'  # WriteFScalar tag in w1
CALL_VARINT = '0x5b3fd04'   # write zigzag varint value
CALL_STRING = '0x55610c8'   # write string value

text = open(sys.argv[1], encoding='utf-8').read().splitlines()
insns = []
for line in text:
    m = re.match(r'^([0-9a-f]+)\s+(\S+)\s*(.*)$', line.strip())
    if m:
        insns.append((int(m.group(1), 16), m.group(2), m.group(3)))

# locate the "field-writing region": instructions that access [x20, #...] and mov w1
MEM_RE = re.compile(r'^(?:ldr|ldp|ldrb|ldrsb|ldrsw)\s+(\w+),?\s*\[x(\d+),\s*#(?:0x([0-9a-f]+)|(\d+))\]')
MOVW1_RE = re.compile(r'^mov\s+w1,\s*#(?:0x([0-9a-f]+)|(\d+))$')
MOVW2_RE = re.compile(r'^mov\s+w2,\s*#(?:0x([0-9a-f]+)|(\d+))$')
BL_RE = re.compile(r'^#(0x[0-9a-f]+)$')

last_mem = None   # (offset, reg, base)
last_w2 = None
out = []
i = 0
while i < len(insns):
    addr, mn, ops = insns[i]
    mm = MEM_RE.match(f'{mn} {ops}') if ops else None
    if mm and mm.group(2) == '20':
        off = int(mm.group(3), 16) if mm.group(3) else int(mm.group(4))
        last_mem = off
    mw = MOVW2_RE.match(f'{mn} {ops}')
    if mw:
        last_w2 = int(mw.group(1), 16) if mw.group(1) else int(mw.group(2))
    m1 = MOVW1_RE.match(f'{mn} {ops}')
    if m1:
        tag = int(m1.group(1), 16) if m1.group(1) else int(m1.group(2))
        # look ahead for the relevant bl
        for j in range(i + 1, min(i + 12, len(insns))):
            _, mn2, ops2 = insns[j]
            if mn2 == 'bl':
                bm = BL_RE.match(ops2)
                if not bm:
                    break
                target = bm.group(1)
                if target == CALL_FSCALAR:
                    out.append((last_mem, tag, 'FScalar/fixed64'))
                    break
                if target == CALL_HEADER:
                    # find the subsequent value write to classify
                    kind = f'header(wire={last_w2})'
                    for k in range(j + 1, min(j + 12, len(insns))):
                        _, mn3, ops3 = insns[k]
                        if mn3 == 'bl':
                            bm3 = BL_RE.match(ops3)
                            t3 = bm3.group(1) if bm3 else ''
                            if t3 == CALL_VARINT:
                                kind = f'variant(zigzag) wire={last_w2}'
                            elif t3 == CALL_STRING:
                                kind = f'string wire={last_w2}'
                            else:
                                kind = f'wire={last_w2} call={t3}'
                            break
                    out.append((last_mem, tag, kind))
                    break
                # other bl with w1 — not a field write; stop scanning
                break
    i += 1

for off, tag, kind in out:
    print(f'obj_off=0x{off:<4x} tag={tag:<4} {kind}')
