#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
"""Extract full field lists for given classes from runtime JSON dumps (v2 readable format)."""
import json, re, sys
from collections import OrderedDict

FIELD_RE = re.compile(r'^(?P<type>.+?) (?P<name>[^ @]+) @0x[0-9A-Fa-f]+$')

def load_schema_fields(cls):
    schema = json.load(open('os.path.join(HERE, '../01_tools/kfb_schema.json')', encoding='utf-8'))
    for t in schema['types']:
        if t['full_name'] == cls or t['full_name'].endswith('.' + cls):
            return {f['name']: f['tag'] for f in t['fields']}, t['full_name']
    return None, None

def collect(cls_short, json_path):
    """Walk runtime json; find dict wrapper keys named KH.<cls_short>; collect field names from inner dict."""
    data = json.load(open(json_path, encoding='utf-8'))
    found = OrderedDict()
    target_keys = set()

    def walk(node):
        if isinstance(node, dict):
            for k, v in list(node.items()):
                short = k.split('.')[-1] if '.' in k else k
                if isinstance(v, dict) and (k == cls_short or short == cls_short or k.endswith('.' + cls_short)):
                    target_keys.add(k)
                    if k in found and found[k] != v:
                        # merge field sets
                        pass
                    found[k] = v
                walk(v)
        elif isinstance(node, list):
            for item in node:
                walk(item)
    walk(data)
    if not found:
        return None
    # union of fields across instances (keep first-seen order per instance)
    fields = OrderedDict()
    for k, v in found.items():
        for fk, fv in v.items():
            m = FIELD_RE.match(fk)
            if m:
                fields.setdefault(m.group('name'), m.group('type'))
    return fields, list(target_keys)

def main():
    for cls in sys.argv[1:]:
        all_fields = OrderedDict()
        for name in ['90059', '90097', '90381']:
            res = collect(cls, os.path.join(HERE, f'../02_samples/runtime_exports/新{name}.json'))
            if res:
                fields, keys = res
                for fn, ft in fields.items():
                    all_fields.setdefault(fn, ft)
        old, old_full = load_schema_fields(cls)
        old = old or {}
        print(f'=== {cls} (schema: {old_full}) ===')
        print(f'  runtime fields ({len(all_fields)}):')
        for fn, ft in all_fields.items():
            mark = '' if fn in old else '   <== NEW'
            print(f'    {fn}: {ft}{mark}')
        missing = set(old) - set(all_fields)
        if missing:
            print(f'  in schema but not in runtime instances: {sorted(missing)}')
        print()

if __name__ == '__main__':
    main()
