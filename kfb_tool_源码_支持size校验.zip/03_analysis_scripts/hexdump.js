#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const file = process.argv[2];
const start = parseInt(process.argv[3], 10);
const end = parseInt(process.argv[4], 10);
const buffer = fs.readFileSync(file);
const hex = buffer.subarray(start, end).toString('hex');
for (let i = 0; i < hex.length; i += 32) {
  console.log(`${String(start + i / 2).padStart(6)}: ${hex.slice(i, i + 32).match(/../g).join(' ')}`);
}
