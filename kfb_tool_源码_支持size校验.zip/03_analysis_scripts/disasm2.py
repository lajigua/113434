#!/usr/bin/env python3
import os
HERE = os.path.dirname(os.path.abspath(__file__))
"""Disassemble a method from libil2cpp.so at a given RVA (arm64), with ELF vaddr->offset mapping."""
import sys, struct
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = os.path.join(HERE, '../04_reverse/libil2cpp.so')

with open(SO, 'rb') as f:
    f.seek(0)
    ident = f.read(16)
    is64 = ident[4] == 2
    f.seek(4 + 8 + 8)  # e_ident, e_type, e_machine -> skip to... actually parse properly
    f.seek(0)
    hdr = f.read(64)
    e_phoff = struct.unpack_from('<Q', hdr, 0x20)[0]
    e_phentsize = struct.unpack_from('<H', hdr, 0x36)[0]
    e_phnum = struct.unpack_from('<H', hdr, 0x38)[0]
    f.seek(e_phoff)
    segments = []
    for i in range(e_phnum):
        ph = f.read(e_phentsize)
        p_type, p_flags = struct.unpack_from('<II', ph, 0)
        p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_align = struct.unpack_from('<QQQQQQ', ph, 8)
        if p_type == 1:  # PT_LOAD
            segments.append((p_vaddr, p_offset, p_filesz, p_memsz))
    def rva2off(rva):
        for vaddr, off, filesz, memsz in segments:
            if vaddr <= rva < vaddr + filesz:
                return off + (rva - vaddr)
        return None

rva = int(sys.argv[1], 16)
size = int(sys.argv[2], 16) if len(sys.argv) > 2 else 0x800
off = rva2off(rva)
if off is None:
    print(f'RVA {rva:#x} not mapped', file=sys.stderr)
    sys.exit(1)
with open(SO, 'rb') as f:
    f.seek(off)
    code = f.read(size)
md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
md.detail = False
for insn in md.disasm(code, rva):
    print(f"{insn.address:08x}  {insn.mnemonic}\t{insn.op_str}")
