#!/usr/bin/env python3
import os
HERE = os.path.dirname(os.path.abspath(__file__))
"""Disassemble a method from libil2cpp.so at a given RVA (arm64)."""
import sys
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = os.path.join(HERE, '../04_reverse/libil2cpp.so')
rva = int(sys.argv[1], 16)
size = int(sys.argv[2], 16) if len(sys.argv) > 2 else 0x800
with open(SO, 'rb') as f:
    f.seek(rva)
    code = f.read(size)
md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
md.detail = False
for insn in md.disasm(code, rva):
    print(f"{insn.address:08x}  {insn.mnemonic}\t{insn.op_str}")
