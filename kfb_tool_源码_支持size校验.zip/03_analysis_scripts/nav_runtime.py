#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
"""Navigate runtime-readable JSON by wire objectPath like $.clipsDataList[1].keyframes[4].Value.frameData.scriptDatas[2]."""
import json, re, sys

def load(name):
    return json.load(open(os.path.join(HERE, f'../02_samples/runtime_exports/新{name}.json'), encoding='utf-8'))

def find_key(d, suffix):
    """Find key in dict whose 'name part' equals suffix. Keys look like:
       '<Type> <name> @0xNN' or 'KH.ClassName' or 'Entry<...>[] name @0xNN'."""
    if not isinstance(d, dict):
        return None
    for k in d.keys():
        if k == suffix:
            return k
        # strip type prefix and offset suffix
        m = re.match(r'^(?:.*? )?([^ @]+)(?: @0x[0-9A-Fa-f]+)?$', k)
        if m and m.group(1) == suffix:
            return k
        # class wrapper 'KH.Xxx'
        if k.endswith('.' + suffix) or k == suffix:
            return k
    # also handle 'Xxx value @0x..' (dictionary entry value)
    for k in d.keys():
        if re.match(rf'^\S*{re.escape(suffix)}\S* (value|Value) @0x', k) or f' {suffix} ' in k:
            return k
    return None

def nav(data, path):
    """path: list of components: name or name[index] or 'Value'."""
    node = {'actorData': data['actorData']}
    for comp in path:
        if node is None:
            return None
        m = re.match(r'^([^\[]+)(?:\[(\d+)\])?$', comp)
        name, idx = m.group(1), m.group(2)
        key = find_key(node, name)
        if key is None:
            # maybe node is a wrapper dict {'KH.ClassName': {...}}
            if isinstance(node, dict) and len(node) >= 1:
                # look inside wrappers
                for wk, wv in node.items():
                    if isinstance(wv, dict):
                        k2 = find_key(wv, name)
                        if k2 is not None:
                            node = wv[k2]
                            if idx is not None:
                                node = node[int(idx)] if isinstance(node, list) else node
                            break
                else:
                    print(f'  [miss] {name} in keys={list(node.keys())[:6]}')
                    return None
                continue
            print(f'  [miss] {name}')
            return None
        node = node[key]
        if idx is not None:
            if isinstance(node, list):
                i = int(idx)
                if i >= len(node):
                    print(f'  [range] {name}[{i}] len={len(node)}')
                    return None
                node = node[i]
            # list wrapped: e.g. entry items
        # unwrap single-key wrappers like {'KH.AnimationClipData': {...}}
        while isinstance(node, dict) and len(node) == 1:
            wk = next(iter(node))
            if re.match(r'^[\w.<>]+\.[\w<>]+$', wk) and isinstance(node[wk], dict):
                node = node[wk]
            else:
                break
    return node

def main():
    name = sys.argv[1] if len(sys.argv) > 1 else '90381'
    wire_path = sys.argv[2] if len(sys.argv) > 2 else '$.clipsDataList[1].keyframes[4].Value.frameData.scriptDatas[2]'
    data = load(name)
    comps = [c for c in wire_path.split('.') if c != '$']
    node = nav(data, comps)
    if node is None:
        print('NAV FAILED')
        return
    print('INSTANCE:')
    print(json.dumps(node, ensure_ascii=False, indent=1)[:3000])

if __name__ == '__main__':
    main()
