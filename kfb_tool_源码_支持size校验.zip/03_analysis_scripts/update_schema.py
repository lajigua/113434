#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
"""Update kfb_schema.json + kfb_dump_layout.json for new-version KFB (AnimationBoxData boxMask/AttackBoxList)."""
import json, shutil, sys

SCHEMA = os.path.join(HERE, '../01_tools/kfb_schema.json')
LAYOUT = os.path.join(HERE, '../01_tools/kfb_dump_layout.json')

ATTACK_BOX_TYPE = 'KH.AnimationBoxData.AttackBox'
LIST_FIELD_TYPE = ('System.Collections.Generic.List`1[[KH.AnimationBoxData.AttackBox, khengine.runtime, '
                   'Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]')

BOX_MASK_FIELD = {
    "tag": 11,
    "serialize_level": 0,
    "name": "boxMask",
    "declared_by": "KH.AnimationBoxData",
    "field_type": "System.Int32",
    "type_code": "Int32",
    "type_code_value": 9,
    "enum_underlying_type_code": "Empty",
    "is_value_type": True,
    "is_enum": False,
    "is_array": False,
    "is_kfb_serializable": False,
    "has_custom_serializer": False,
    "is_list": False,
    "is_dictionary": False,
    "polymorphic": False,
    "skip_default": False,
    "skip_default_implicit": True,
    "wire_type_hint": "Variant",
    "display_type": "Int32",
    "editable_name": "boxMask",
}

ATTACK_BOX_LIST_FIELD = {
    "tag": 12,
    "serialize_level": 0,
    "name": "AttackBoxList",
    "declared_by": "KH.AnimationBoxData",
    "field_type": LIST_FIELD_TYPE,
    "type_code": "Object",
    "type_code_value": 1,
    "enum_underlying_type_code": "Empty",
    "is_value_type": False,
    "is_enum": False,
    "is_array": False,
    "is_kfb_serializable": False,
    "has_custom_serializer": False,
    "is_list": True,
    "is_dictionary": False,
    "polymorphic": False,
    "skip_default": False,
    "skip_default_implicit": False,
    "wire_type_hint": "List",
    "element_type": ATTACK_BOX_TYPE,
    "display_type": "List<KH.AnimationBoxData.AttackBox>",
    "editable_name": "AttackBoxList",
}

def main():
    # backup once
    for p in (SCHEMA, LAYOUT):
        if not shutil.copy2(p, p + '.bak_v2'):
            sys.exit(1)

    schema = json.load(open(SCHEMA, encoding='utf-8'))
    names = {t['full_name'] for t in schema['types']}
    assert 'KH.AnimationBoxData' in names, 'AnimationBoxData missing'

    # 1. add fields to AnimationBoxData
    for t in schema['types']:
        if t['full_name'] == 'KH.AnimationBoxData':
            tags = {f['tag'] for f in t['fields']}
            if 11 not in tags:
                t['fields'].append(BOX_MASK_FIELD)
            if 12 not in tags:
                t['fields'].append(ATTACK_BOX_LIST_FIELD)
            t['fields'].sort(key=lambda f: f['tag'])
            break

    # 2. register AttackBox placeholder type (fields unknown: no sample with
    #    non-empty AttackBoxList exists; wire items are length-prefixed objects)
    if ATTACK_BOX_TYPE not in names:
        schema['types'].append({
            "full_name": ATTACK_BOX_TYPE,
            "is_array": False,
            "is_enum": False,
            "is_value_type": False,
            "base_type": "System.Object",
            "type_id": None,
            "polymorphic": True,
            "has_custom_serializer": False,
            "fields": [],
            "default_json": "{}",
            "template_json": {ATTACK_BOX_TYPE: {}},
            "template_xml": "<KFBObject kfbType=\"KH.AnimationBoxData.AttackBox\" />\n",
            "template_status": "ok",
            "template_error": None,
        })
    json.dump(schema, open(SCHEMA, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    # 3. layout update
    layout = json.load(open(LAYOUT, encoding='utf-8'))
    box = layout['types']['KH.AnimationBoxData']
    box['fields']['boxMask'] = {"type": "System.Int32", "offset": "0x1F8"}
    box['fields']['AttackBoxList'] = {
        "type": "System.Collections.Generic.List<KH.AnimationBoxData.AttackBox>",
        "offset": "0x1F0",
    }
    if ATTACK_BOX_TYPE not in layout['types']:
        layout['types'][ATTACK_BOX_TYPE] = {
            "fullName": ATTACK_BOX_TYPE, "baseType": "System.Object", "fields": {},
        }
        layout['type_count'] = len(layout['types'])
    json.dump(layout, open(LAYOUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    print('schema types:', len(schema['types']), 'layout types:', len(layout['types']))
    print('updated OK')

if __name__ == '__main__':
    main()
