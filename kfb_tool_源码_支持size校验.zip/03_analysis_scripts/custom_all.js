#!/usr/bin/env node
'use strict';
// Dump ALL custom (wire-3) sub-blocks: offset, parsed value, leftover, raw hex of the block.
const fs = require('node:fs');
const decoder = require('../01_tools/kfb_schema_decoder.js');

const SCHEMA = __dirname + '/../01_tools/kfb_schema.json';
const schema = decoder.normalizeSchema(JSON.parse(fs.readFileSync(SCHEMA, 'utf8')));

const file = process.argv[2];
const buffer = fs.readFileSync(file);
const result = decoder.decodeKfb(buffer, schema, { lenientUnknown: true });

// Collect every custom field occurrence from the AST, plus unknown leftovers.
function walk(node, path, out) {
  if (!node || typeof node !== 'object') return;
  if (node.kind === 'custom') {
    out.push({ path, offset: node.offset, endOffset: node.endOffset, type: node.type, value: node.value });
  }
  for (const key of Object.keys(node)) {
    const v = node[key];
    if (Array.isArray(v)) v.forEach((c, i) => walk(c, `${path}.${key}[${i}]`, out));
    else if (v && typeof v === 'object' && v.kind) walk(v, `${path}.${key}`, out);
  }
}
const customs = [];
walk(result.ast, '$', customs);
console.log(`custom nodes: ${customs.length}`);
for (const c of customs.slice(0, 40)) {
  const start = Math.max(0, c.offset - 8);
  const hex = buffer.slice(start, c.endOffset + 6).toString('hex').replace(/(..)/g, '$1 ').trim();
  console.log(`${c.path}  [${c.offset}..${c.endOffset}] type=${c.type} value=${c.value}`);
  console.log(`   ctx: ${hex}`);
}
