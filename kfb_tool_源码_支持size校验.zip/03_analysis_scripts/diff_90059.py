#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
import sys

a = open('os.path.join(HERE, '../02_samples/static_decrypted/90059.kfb')', 'rb').read()      # static decrypt result
b = open(os.path.join(HERE, '../02_samples/runtime_exports/新90059.kfb'), 'rb').read()   # runtime output

print(f'static size={len(a)}, runtime size={len(b)}')

# find diff regions
diffs = []
i = 0
n = min(len(a), len(b))
while i < n:
    if a[i] != b[i]:
        start = i
        while i < n and a[i] != b[i]:
            i += 1
        diffs.append((start, i))
    else:
        i += 1

print(f'diff regions: {len(diffs)}')
total = sum(e - s for s, e in diffs)
print(f'total diff bytes: {total}')

for s, e in diffs[:20]:
    ctx_s = max(0, s - 16)
    ctx_e = min(n, e + 16)
    print(f'--- region [{s}, {e}) len={e-s}')
    print(f'  static : {a[ctx_s:ctx_e].hex()}')
    print(f'  runtime: {b[ctx_s:ctx_e].hex()}')

if len(diffs) > 20:
    print('...')
    # check whether all diffs are 4-byte aligned patterns (e.g. floats)
    lens = {}
    for s, e in diffs:
        lens[e - s] = lens.get(e - s, 0) + 1
    print('region length histogram:', sorted(lens.items(), key=lambda kv: -kv[1])[:10])
