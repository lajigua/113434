#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Schema v2 update: add new-version fields (from libil2cpp.so ReadField/WriteField disassembly)
and new type KH.SetSubCircleIconArg. Updates kfb_schema.json + kfb_dump_layout.json (with .bak_v4 backups).

Tag extraction evidence:
- AOEScriptArg ReadField @0x42d2dfc jump table (0x16235aa, max tag 31): t20->0x149 ... t31->0x158
- SearchElementWithSSTypeArg ReadField @0x7019de8: t2->str [x19+0xb8], t4->str [x19+0xc8]
- ChangeTargetArg ReadField @0x6fa5a64 jump table (0x1622e24, max 51): t50->strb 0x1f1, t51->strb 0x1f2
- SetSkillCircleCursorArg ReadField @0x6fe8970 jump table (0x1625e80, max 13):
  t10->0x68 (List), t11->str x1,[x19+0x70] (String), t12->strb 0x78, t13->stp x21,x22,[x19+0x80] (FScalar)
- TSHitTestArg ReadField @0x5c89b3c jump table (0x1626436, max 32): t32->strb 0x154;
  t30 = hurtBuffIdList (only remaining field, slot between t29 hurtBuffIdStr@0x140 and t31 objectFrameIndex@0x14c)
- SetSubCircleIconArg WriteField @0x6ff30a8 (handoff doc §6.4): t1-t7 alias..bgOffsetY
"""
import json, os, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SCHEMA = os.path.join(HERE, '../01_tools/kfb_schema.json')
LAYOUT = os.path.join(HERE, '../01_tools/kfb_dump_layout.json')

MSCORLIB_INT32 = "System.Collections.Generic.List`1[[System.Int32, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]"
LIST_SUBCIRCLE = "System.Collections.Generic.List`1[[KH.SetSubCircleIconArg, khengine.runtime, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null]]"

def F(name, declared_by, ftype, **kw):
    """Build a schema field entry by inference from existing same-kind fields."""
    f = {
        "tag": kw.pop("tag"),
        "serialize_level": 0,
        "name": name,
        "declared_by": declared_by,
        "field_type": ftype,
        "type_code": kw.pop("type_code"),
        "type_code_value": kw.pop("type_code_value"),
        "enum_underlying_type_code": kw.pop("enum_underlying_type_code", "Empty"),
        "is_value_type": kw.pop("is_value_type"),
        "is_enum": kw.pop("is_enum", False),
        "is_array": False,
        "is_kfb_serializable": kw.pop("is_kfb_serializable", False),
        "has_custom_serializer": kw.pop("has_custom_serializer", False),
        "is_list": kw.pop("is_list", False),
        "is_dictionary": False,
        "polymorphic": kw.pop("polymorphic", False),
        "skip_default": False,
        "skip_default_implicit": kw.pop("skip_default_implicit", True),
        "wire_type_hint": kw.pop("wire_type_hint"),
        "display_type": kw.pop("display_type"),
        "editable_name": name,
    }
    if "element_type" in kw: f["element_type"] = kw.pop("element_type")
    assert not kw, f"unused kwargs {kw}"
    return f

def Boolean(tag, name, by): return F(name, by, "System.Boolean", tag=tag, type_code="Boolean", type_code_value=3,
    is_value_type=True, skip_default_implicit=True, wire_type_hint="Variant", display_type="Boolean")
def Int32(tag, name, by): return F(name, by, "System.Int32", tag=tag, type_code="Int32", type_code_value=9,
    is_value_type=True, skip_default_implicit=True, wire_type_hint="Variant", display_type="Int32")
def String(tag, name, by): return F(name, by, "System.String", tag=tag, type_code="String", type_code_value=18,
    is_value_type=False, skip_default_implicit=False, wire_type_hint="String", display_type="String")
def FScalar(tag, name, by): return F(name, by, "Morefun.LockStep.FScalar", tag=tag, type_code="Object", type_code_value=1,
    is_value_type=True, has_custom_serializer=True, skip_default_implicit=True, wire_type_hint="Object", display_type="FScalar")
def EnumInt32(tag, name, by, etype): return F(name, by, etype, tag=tag, type_code="Int32", type_code_value=9,
    enum_underlying_type_code="Int32", is_value_type=True, is_enum=True, skip_default_implicit=False,
    wire_type_hint="Variant", display_type=etype.split('.')[-1])
def KfbObject(tag, name, by, etype): return F(name, by, etype, tag=tag, type_code="Object", type_code_value=1,
    is_value_type=False, is_kfb_serializable=True, polymorphic=True, skip_default_implicit=False,
    wire_type_hint="Object", display_type=etype)
def ListOf(tag, name, by, elem, field_type=None): return F(name, by, field_type or ("System.Collections.Generic.List`1[[%s]]" % elem),
    tag=tag, type_code="Object", type_code_value=1, is_value_type=False, is_list=True, skip_default_implicit=False,
    wire_type_hint="List", display_type="List<%s>" % elem, element_type=elem)

def tpl_scalar(): return {"Int64 rawValue": 0, "Boolean HasInit": True}

# ---- new field definitions: (typeName, [(tag, builder)], layout offsets, default_json keys, template keys) ----
NEW_FIELDS = {
    "KH.AOEScriptArg": {
        "fields": [
            (20, lambda by: Boolean(20, "aoeAllowItemDetect", by)),
            (21, lambda by: Boolean(21, "recursiveFindObjectFrame", by)),
            (22, lambda by: Boolean(22, "isContinuous", by)),
            (23, lambda by: Int32(23, "durationFrame", by)),
            (24, lambda by: EnumInt32(24, "continuousKeepType", by, "KH.EScriptKeepType")),
            (25, lambda by: Int32(25, "leaveAoeType", by)),
            (26, lambda by: Int32(26, "leaveAoeID", by)),
            (27, lambda by: String(27, "leaveAoeExtraArg", by)),
            (28, lambda by: Boolean(28, "leaveBind", by)),
            (29, lambda by: Boolean(29, "useAttackBoxParams", by)),
            (30, lambda by: String(30, "name", by)),
            (31, lambda by: Boolean(31, "stop", by)),
        ],
        "layout": {"aoeAllowItemDetect": "0x149", "recursiveFindObjectFrame": "0x14A", "isContinuous": "0x14B",
                   "name": "0x150", "stop": "0x158", "durationFrame": "0x15C", "continuousKeepType": "0x160",
                   "leaveAoeType": "0x164", "leaveAoeID": "0x168", "leaveAoeExtraArg": "0x170",
                   "leaveBind": "0x178", "useAttackBoxParams": "0x179"},
        "defaults": {"aoeAllowItemDetect": False, "recursiveFindObjectFrame": False, "isContinuous": False,
                     "durationFrame": 0, "continuousKeepType": 0, "leaveAoeType": 0, "leaveAoeID": 0,
                     "leaveAoeExtraArg": "", "leaveBind": False, "useAttackBoxParams": False,
                     "name": "", "stop": False},
    },
    "KH.SearchElementWithSSTypeArg": {
        "fields": [
            (3, lambda by: Boolean(3, "enableKFLCondition", by)),
            (4, lambda by: KfbObject(4, "kflCondition", by, "KFL.KFLBoolParameterInfo")),
        ],
        "layout": {"enableKFLCondition": "0xC0", "kflCondition": "0xC8"},
        "defaults": {"enableKFLCondition": False, "kflCondition": None},
    },
    "KH.ChangeTargetArg": {
        "fields": [
            (50, lambda by: Boolean(50, "checkBorder", by)),
            (51, lambda by: Boolean(51, "recursiveFindObjectFrame", by)),
        ],
        "layout": {"checkBorder": "0x1F1", "recursiveFindObjectFrame": "0x1F2"},
        "defaults": {"checkBorder": False, "recursiveFindObjectFrame": False},
    },
    "KH.SetSkillCircleCursorArg": {
        "fields": [
            (10, lambda by: ListOf(10, "setSubCirclelst", by, "KH.SetSubCircleIconArg", LIST_SUBCIRCLE)),
            (11, lambda by: String(11, "rockerIconPath", by)),
            (12, lambda by: Boolean(12, "isFollowRotation", by)),
            (13, lambda by: FScalar(13, "radius", by)),
        ],
        "layout": {"setSubCirclelst": "0x68", "rockerIconPath": "0x70", "isFollowRotation": "0x78", "radius": "0x80"},
        "defaults": {"setSubCirclelst": [], "rockerIconPath": "", "isFollowRotation": False, "radius": "0"},
    },
    "KH.TSHitTestArg": {
        "fields": [
            (30, lambda by: ListOf(30, "hurtBuffIdList", by, "System.Int32", MSCORLIB_INT32)),
            (32, lambda by: Boolean(32, "recursiveFindObjectFrame", by)),
        ],
        "layout": {"hurtBuffIdList": "0x148", "recursiveFindObjectFrame": "0x154"},
        "defaults": {"hurtBuffIdList": [], "recursiveFindObjectFrame": False},
    },
}

SUB_TYPE_NAME = "KH.SetSubCircleIconArg"
SUB_TYPE_ID = 710

def build_subcircle_type():
    by = SUB_TYPE_NAME
    fields = [
        String(1, "alias", by),
        String(2, "iconPath", by),
        String(3, "bgPath", by),
        FScalar(4, "rotationRatio", by),
        Int32(5, "setType", by),
        FScalar(6, "bgOffsetX", by),
        FScalar(7, "bgOffsetY", by),
    ]
    default_obj = {"$tid": SUB_TYPE_ID, "alias": "", "iconPath": "", "bgPath": "",
                   "rotationRatio": {"rawValue": 0, "HasInit": False}, "setType": 0,
                   "bgOffsetX": {"rawValue": 0, "HasInit": False}, "bgOffsetY": {"rawValue": 0, "HasInit": False}}
    template = {SUB_TYPE_NAME: {
        "String alias": "", "String iconPath": "", "String bgPath": "",
        "FScalar rotationRatio": tpl_scalar(), "Int32 setType": 0,
        "FScalar bgOffsetX": tpl_scalar(), "FScalar bgOffsetY": tpl_scalar(),
    }}
    xml_fields = []
    for name, dt, dv in [("alias", "System.String", ""), ("iconPath", "System.String", ""),
                          ("bgPath", "System.String", ""), ("rotationRatio", "Morefun.LockStep.FScalar", "0"),
                          ("setType", "System.Int32", "0"), ("bgOffsetX", "Morefun.LockStep.FScalar", "0"),
                          ("bgOffsetY", "Morefun.LockStep.FScalar", "0")]:
        tag = dt.split('.')[-1]
        xml_fields.append(f'  <Field name="{name}" declaredType="{dt}">\n    <{tag}>{dv}</{tag}>\n  </Field>')
    template_xml = f'<KFBObject kfbType="{SUB_TYPE_NAME}">\n' + "\n".join(xml_fields) + "\n</KFBObject>"
    return {
        "full_name": SUB_TYPE_NAME,
        "is_array": False,
        "is_enum": False,
        "is_value_type": False,
        "base_type": "System.Object",
        "type_id": SUB_TYPE_ID,
        "polymorphic": True,
        "has_custom_serializer": False,
        "fields": fields,
        "default_json": json.dumps(default_obj, ensure_ascii=False, indent=4),
        "template_json": template,
        "template_xml": template_xml,
        "template_status": "ok",
        "template_error": None,
    }

def update_schema(schema):
    by_name = {t.get("full_name") or t.get("name"): t for t in schema["types"]}
    # build descendant map: base -> [all transitive subtypes]
    direct_children = {}
    for t in schema["types"]:
        base = t.get("base_type")
        if base and base != "System.Object":
            direct_children.setdefault(base, []).append(t.get("full_name") or t.get("name"))
    def descendants(name, seen=None):
        if seen is None: seen = set()
        out = []
        for ch in direct_children.get(name, []):
            if ch in seen: continue
            seen.add(ch)
            out.append(ch)
            out.extend(descendants(ch, seen))
        return out
    report = []
    for tname, spec in NEW_FIELDS.items():
        t = by_name[tname]
        # schema type entries flatten inherited fields: append new fields (declared_by=tname)
        # to tname itself AND every transitive subtype entry.
        targets = [tname] + [d for d in descendants(tname) if d in by_name]
        existing_here = {f["tag"] for f in t["fields"] if f["declared_by"] == tname}
        added = []
        for tag, builder in spec["fields"]:
            entry = builder(tname)
            newly_here = tag not in existing_here
            for target in targets:
                tt = by_name[target]
                if any(f["tag"] == tag and f["declared_by"] == tname for f in tt["fields"]):
                    continue
                tt["fields"].append(dict(entry))
            if newly_here:
                added.append(tag)
        # defaults: merge new keys into default_json / template_json / template_xml attributes
        dj = json.loads(t["default_json"]) if t.get("default_json") else {}
        dj.update(spec["defaults"])
        t["default_json"] = json.dumps(dj, ensure_ascii=False, indent=4)
        tj = t.get("template_json") or {}
        inner = tj.get(tname)
        if isinstance(inner, dict):
            for tag, builder in spec["fields"]:
                fld = [f for f in t["fields"] if f["tag"] == tag and f["declared_by"] == tname]
                if not fld: continue
                fld = fld[0]
                key = f"{fld['display_type']} {fld['name']}"
                if fld["display_type"] == "FScalar": inner[key] = tpl_scalar()
                elif fld["is_list"]: inner[key] = []
                elif fld["is_enum"] or fld["type_code"] in ("Int32", "Boolean"): inner[key] = spec["defaults"][fld["name"]]
                else: inner[key] = spec["defaults"][fld["name"]]
        tx = t.get("template_xml") or ""
        if tx.startswith("<KHScriptData") and tx.rstrip().endswith("/>"):
            attrs = []
            for tag, _ in spec["fields"]:
                fld = [f for f in t["fields"] if f["tag"] == tag and f["declared_by"] == tname][0]
                dv = spec["defaults"][fld["name"]]
                if fld["display_type"] == "FScalar": dv = "0"
                elif isinstance(dv, bool): dv = str(dv)
                elif isinstance(dv, list): dv = ""
                else: dv = str(dv)
                attrs.append(f'{fld["name"]}="{dv}"')
            tx = tx.rstrip()[:-2].rstrip() + " " + " ".join(attrs) + " />"
            t["template_xml"] = tx
        report.append(f"ADD {tname}: tags {added} (flattened into {len(targets)} type entries: {', '.join(targets[:6])}{'...' if len(targets) > 6 else ''})")
    if SUB_TYPE_NAME not in by_name:
        schema["types"].append(build_subcircle_type())
        report.append(f"ADD TYPE {SUB_TYPE_NAME} type_id={SUB_TYPE_ID} (7 fields t1-t7)")
    else:
        report.append(f"SKIP TYPE {SUB_TYPE_NAME} (already present)")
    return report

def update_layout(layout):
    types = layout["types"]
    report = []
    for tname, spec in NEW_FIELDS.items():
        if tname not in types:
            report.append(f"WARN layout missing {tname}")
            continue
        flds = types[tname].setdefault("fields", {})
        for name, off in spec["layout"].items():
            if name not in flds:
                flds[name] = {"type": "unknown"}
        # fill correct CLR types (dump.cs)
        clr = {
            "KH.AOEScriptArg": {"aoeAllowItemDetect": "System.Boolean", "recursiveFindObjectFrame": "System.Boolean",
                "isContinuous": "System.Boolean", "name": "System.String", "stop": "System.Boolean",
                "durationFrame": "System.Int32", "continuousKeepType": "KH.EScriptKeepType",
                "leaveAoeType": "System.Int32", "leaveAoeID": "System.Int32", "leaveAoeExtraArg": "System.String",
                "leaveBind": "System.Boolean", "useAttackBoxParams": "System.Boolean"},
            "KH.SearchElementWithSSTypeArg": {"enableKFLCondition": "System.Boolean", "kflCondition": "KFL.KFLBoolParameterInfo"},
            "KH.ChangeTargetArg": {"checkBorder": "System.Boolean", "recursiveFindObjectFrame": "System.Boolean"},
            "KH.SetSkillCircleCursorArg": {"setSubCirclelst": "System.Collections.Generic.List<KH.SetSubCircleIconArg>",
                "rockerIconPath": "System.String", "isFollowRotation": "System.Boolean",
                "radius": "Morefun.LockStep.FScalar"},
            "KH.TSHitTestArg": {"hurtBuffIdList": "System.Collections.Generic.List<System.Int32>",
                "recursiveFindObjectFrame": "System.Boolean"},
        }[tname]
        for name, off in spec["layout"].items():
            flds[name] = {"type": clr.get(name, flds[name]["type"]), "offset": off}
        report.append(f"LAYOUT {tname}: +{len(spec['layout'])} fields")
    if SUB_TYPE_NAME not in types:
        types[SUB_TYPE_NAME] = {
            "fullName": SUB_TYPE_NAME,
            "baseType": "System.Object",
            "fields": {
                "alias": {"type": "System.String", "offset": "0x10"},
                "iconPath": {"type": "System.String", "offset": "0x18"},
                "bgPath": {"type": "System.String", "offset": "0x20"},
                "rotationRatio": {"type": "Morefun.LockStep.FScalar", "offset": "0x28"},
                "setType": {"type": "System.Int32", "offset": "0x38"},
                "bgOffsetX": {"type": "Morefun.LockStep.FScalar", "offset": "0x40"},
                "bgOffsetY": {"type": "Morefun.LockStep.FScalar", "offset": "0x50"},
            },
        }
        layout["type_count"] = len(types)
        report.append(f"LAYOUT TYPE {SUB_TYPE_NAME} added")
    return report

def main():
    for p in (SCHEMA, LAYOUT):
        bak = p + ".bak_v4"
        if not os.path.exists(bak):
            shutil.copy2(p, bak)
            print(f"backup -> {bak}")
    schema = json.load(open(SCHEMA, encoding="utf-8"))
    layout = json.load(open(LAYOUT, encoding="utf-8"))
    for line in update_schema(schema): print(line)
    for line in update_layout(layout): print(line)
    json.dump(schema, open(SCHEMA, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    json.dump(layout, open(LAYOUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("written:", SCHEMA)
    print("written:", LAYOUT)

if __name__ == "__main__":
    main()
