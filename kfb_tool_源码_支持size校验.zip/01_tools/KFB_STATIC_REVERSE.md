# KFB 静态解密逆向结果

## 已确认流程

`KH.ActorDataFileUtil.LoadBytes/DecryptBytes/Decrypt` 的资源层容器为：

```text
offset 0x00  4 bytes   外层头（解密时保留但不参与 AES）
offset 0x04  16 bytes  AES CTR IV / 初始计数器（大端数值语义）
offset 0x14  N bytes   AES-256-CTR 密文
```

AES 解密后的数据为 LZ4 block：

```text
offset 0x00  uint32 LE  解压后长度
offset 0x04  N bytes    原始 LZ4 block
```

证据：

- `libil2cpp.so` 中同时存在 `EVP_aes_256_ctr` 和 `LZ4_decompress_safe`。
- 现有 `khcrypt.py` 使用相同的 `data[4:20]` IV、AES-CTR 和 LZ4 顺序。
- `uabea_decrypted.assetbundle` 被识别为 `LogicData_Actor_90097_p`，大小 40375。
- UnityFS 中 `90097_p` TextAsset 的密文长度为 39008。
- 使用角色 key 脱敏摘要 `c49ad87a...6ae7df0e` 静态解密后得到 484167 字节 XML。
- XML SHA-256：`3C6A75BD107F6074FC7B157AC65974BDC50558FF50A40AC1B952801F8DA71BDB`。
- XML 根节点从 `<AnimationData ...>` 开始并以 `</AnimationData>` 结束。

## KFB 二进制层

另一个运行时明文样本是 KFBuffers 二进制，不是 XML。其字段头格式已确认：

```text
header = unsigned_varint
field_number = header >> 3
wire_type = header & 7
```

wire type：

```text
0 Variant
1 Fixed32
2 Fixed64
3 Object
4 String
5 List
6 Dictionary
7 Packed
```

样本首字段为 `14 0C "NormalShadow"`：`0x14 >> 3 = 2`，wire type 4，长度 12，
对应 `KH.ActorData.shadowName`。静态工具提供 schema-less wire 检查；完整的二进制
KFB → 语义 XML 仍需导出 `KFBTypeModel` 的 type-id、字段号和自定义 serializer schema。

## 工具

```powershell
# 直接从 UnityFS 中提取 TextAsset 并静态解密
node D:\IDA93\1\逆向\kfb_static_decrypt.js decrypt-bundle `
  D:\IDA93\1\uabea_decrypted.assetbundle 90097_p D:\tmp\90097_p.xml `
  --key-db D:\tmp\ninja_aes_keys.json --ninja-id 90097

# 已经提取出 TextAsset 时
node D:\IDA93\1\逆向\kfb_static_decrypt.js decrypt `
  D:\tmp\90097_p.bytes D:\tmp\90097_p.xml `
  --key-db D:\tmp\ninja_aes_keys.json --ninja-id 90097

# 检查明文二进制 KFB 的 wire 结构
node D:\IDA93\1\逆向\kfb_static_decrypt.js inspect `
  D:\tmp\plain.kfb D:\tmp\plain.wire.json --max-depth 2
```
