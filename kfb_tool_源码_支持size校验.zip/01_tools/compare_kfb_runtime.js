'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

function usage() {
  console.error('Usage: node compare_kfb_runtime.js <static.json> <runtime.json> <static.kfb> <runtime.kfb> <schema.json> <report.json>');
  process.exit(2);
}

if (process.argv.length !== 8) usage();

const [staticJsonPath, runtimeJsonPath, staticKfbPath, runtimeKfbPath, schemaPath, reportPath] = process.argv.slice(2);

function sha256(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex').toUpperCase();
}

function fieldName(reflectionKey) {
  const withoutOffset = reflectionKey.replace(/ @0x[0-9A-Fa-f]+$/, '');
  const space = withoutOffset.lastIndexOf(' ');
  return space < 0 ? withoutOffset : withoutOffset.slice(space + 1);
}

function field(object, name) {
  if (!object || typeof object !== 'object' || Array.isArray(object)) return undefined;
  const key = Object.keys(object).find((candidate) => fieldName(candidate) === name);
  return key === undefined ? undefined : object[key];
}

function typedValue(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const keys = Object.keys(value);
  if (keys.length !== 1 || !keys[0].includes('.')) return null;
  return { type: keys[0], value: value[keys[0]] };
}

function isRuntimeReference(value) {
  return typeof value === 'string' && /^\((?:circular-reference|null-object|depth-limit)/.test(value);
}

function runtimeString(value) {
  const typed = typedValue(value);
  if (typed) value = typed.value;
  if (typeof value === 'string' && /^\(circular-reference /.test(value)) return '';
  return value;
}

function runtimeList(value) {
  return Array.isArray(value) ? value : [];
}

function dictionaryEntries(dictionary) {
  const entries = runtimeList(field(dictionary, '_entries'));
  const count = Number(field(dictionary, '_count') ?? entries.length);
  const result = [];
  for (const entry of entries.slice(0, count)) {
    const hashCode = field(entry, 'hashCode');
    const value = field(entry, 'value');
    if (typeof hashCode === 'number' && hashCode < 0) continue;
    if (value === '(null-object)') continue;
    result.push({ key: field(entry, 'key'), value });
  }
  return result;
}

function customScalar(value) {
  if (!value || typeof value !== 'object') return { comparable: false, value: null };
  const raw = field(value, 'rawValue');
  if (typeof raw === 'number') {
    if (!Number.isSafeInteger(raw)) return { comparable: false, value: String(raw) };
    return { comparable: true, value: String(raw) };
  }
  if (typeof raw === 'string' && /^-?\d+$/.test(raw)) return { comparable: true, value: raw };
  return { comparable: false, value: raw };
}

function customValue(value) {
  if (!value || typeof value !== 'object') return { comparable: false, value: null };
  if (field(value, 'rawValue') !== undefined) return customScalar(value);
  const components = ['x', 'y', 'z', 'w'].filter((name) => field(value, name) !== undefined);
  if (components.length === 0) return { comparable: false, value: null };
  const parts = components.map((name) => customScalar(field(value, name)));
  return {
    comparable: parts.every((part) => part.comparable),
    value: parts.map((part) => part.value).join(','),
  };
}

const staticJson = JSON.parse(fs.readFileSync(staticJsonPath, 'utf8'));
const runtimeCapture = JSON.parse(fs.readFileSync(runtimeJsonPath, 'utf8'));
const runtimeActor = runtimeCapture.actorData;
const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
const staticKfb = fs.readFileSync(staticKfbPath);
const runtimeKfb = fs.readFileSync(runtimeKfbPath);
const typeById = new Map(schema.types.filter((type) => type.type_id !== null).map((type) => [Number(type.type_id), type.full_name]));

const mismatches = [];
const stats = {
  checks: 0,
  matches: 0,
  skippedRuntimeReferences: 0,
  skippedUnsafeIntegers: 0,
  clips: 0,
  keyframes: 0,
  boxVectors: 0,
  frameData: 0,
  scripts: 0,
  objectFrames: 0,
};

function same(pathName, actual, expected) {
  stats.checks += 1;
  if (Object.is(actual, expected)) {
    stats.matches += 1;
    return;
  }
  mismatches.push({ path: pathName, static: actual, runtime: expected });
}

function compareCustom(pathName, staticValue, runtimeValue) {
  if (isRuntimeReference(runtimeValue)) {
    stats.skippedRuntimeReferences += 1;
    return;
  }
  const normalized = customValue(runtimeValue);
  if (!normalized.comparable) {
    stats.skippedUnsafeIntegers += 1;
    return;
  }
  same(pathName, String(staticValue), normalized.value);
}

function compareRuntimeScalar(pathName, staticValue, runtimeValue) {
  if (typeof staticValue === 'string') runtimeValue = runtimeString(runtimeValue);
  same(pathName, staticValue, runtimeValue);
}

function compareScriptList(pathName, staticScripts, runtimeScripts) {
  staticScripts = Array.isArray(staticScripts) ? staticScripts : [];
  runtimeScripts = runtimeList(runtimeScripts);
  same(`${pathName}.length`, staticScripts.length, runtimeScripts.length);
  const count = Math.min(staticScripts.length, runtimeScripts.length);
  for (let index = 0; index < count; index += 1) {
    const staticScript = staticScripts[index];
    const runtimeTyped = typedValue(runtimeScripts[index]);
    if (!runtimeTyped || isRuntimeReference(runtimeTyped.value)) {
      stats.skippedRuntimeReferences += 1;
      continue;
    }
    stats.scripts += 1;
    same(`${pathName}[${index}].type`, typeById.get(Number(staticScript.$tid)), runtimeTyped.type);
    for (const name of ['scriptType', 'argInt', 'argStr']) {
      compareRuntimeScalar(`${pathName}[${index}].${name}`, staticScript[name], field(runtimeTyped.value, name));
    }
  }
}

function compareFrameData(pathName, staticFrame, runtimeFrame) {
  if (staticFrame == null || runtimeFrame == null || runtimeFrame === '(null-object)') {
    same(`${pathName}.presence`, staticFrame == null, runtimeFrame == null || runtimeFrame === '(null-object)');
    return;
  }
  if (isRuntimeReference(runtimeFrame)) {
    stats.skippedRuntimeReferences += 1;
    return;
  }
  stats.frameData += 1;
  compareRuntimeScalar(`${pathName}.index`, staticFrame.index, field(runtimeFrame, 'index'));
  compareRuntimeScalar(`${pathName}.once`, staticFrame.once, field(runtimeFrame, 'once'));
  compareScriptList(`${pathName}.scriptDatas`, staticFrame.scriptDatas, field(runtimeFrame, 'scriptDatas'));
  compareScriptList(`${pathName}.scriptDatasForSounds`, staticFrame.scriptDatasForSounds, field(runtimeFrame, 'scriptDatasForSounds'));
  compareScriptList(`${pathName}.scriptDatasForEffects`, staticFrame.scriptDatasForEffects, field(runtimeFrame, 'scriptDatasForEffects'));
}

const boxFields = [
  'attack_pos', 'attack_size', 'weapon_pos', 'weapon_size',
  'hurt_pos0', 'hurt_size0', 'hurt_pos1', 'hurt_size1', 'hurt_pos2', 'hurt_size2',
];

function compareAnimationFrame(pathName, staticFrame, runtimeFrame) {
  compareRuntimeScalar(`${pathName}.index`, staticFrame.index, field(runtimeFrame, 'index'));
  compareRuntimeScalar(`${pathName}.eventType`, staticFrame.eventType, field(runtimeFrame, 'eventType'));
  const staticBox = staticFrame.boxData;
  const runtimeBox = field(runtimeFrame, 'boxData');
  if (staticBox && runtimeBox && !isRuntimeReference(runtimeBox)) {
    for (const name of boxFields) {
      stats.boxVectors += 1;
      compareCustom(`${pathName}.boxData.${name}`, staticBox[name], field(runtimeBox, name));
    }
  } else {
    same(`${pathName}.boxData.presence`, Boolean(staticBox), Boolean(runtimeBox && runtimeBox !== '(null-object)'));
  }
  compareFrameData(`${pathName}.frameData`, staticFrame.frameData, field(runtimeFrame, 'frameData'));
}

const rootFields = [
  'shadowName', 'useBody', 'unitMaterial', 'sufferAudioID', 'deadAudioID', 'needGroupChange',
  'defSelfGroupID', 'CreateScriptID', 'fightAgainJumpInEndScript', 'assistantPVPJumpOutScript',
  'assistantPVPJumpInScript', 'defaultVKey', 'disappearVKey', 'AI_Active', 'AI_tempID',
  'AI_configID', 'reviveFlag', 'reviveBuffId', 'allowMotionIdCheck', 'hurtActionNotChangeState',
  'noJumpInScript',
];
for (const name of rootFields) compareRuntimeScalar(`ActorData.${name}`, staticJson[name], field(runtimeActor, name));
for (const name of ['mapOffset', 'viewHeight', 'viewWidth', 'viewZSzie', 'shadowSize', 'shadowOffset']) {
  compareCustom(`ActorData.${name}`, staticJson[name], field(runtimeActor, name));
}

const runtimeClipEntries = dictionaryEntries(field(runtimeActor, 'clipsData'));
const staticClips = Array.isArray(staticJson.clipsDataList) ? staticJson.clipsDataList : [];
same('ActorData.clipsDataList.length', staticClips.length, runtimeClipEntries.length);
for (let clipIndex = 0; clipIndex < Math.min(staticClips.length, runtimeClipEntries.length); clipIndex += 1) {
  const staticClip = staticClips[clipIndex];
  const runtimeEntry = runtimeClipEntries[clipIndex];
  const runtimeClip = runtimeEntry.value;
  const base = `ActorData.clipsDataList[${clipIndex}]`;
  if (isRuntimeReference(runtimeClip)) {
    stats.skippedRuntimeReferences += 1;
    continue;
  }
  stats.clips += 1;
  for (const name of ['name', 'totalframes', 'renderframes', 'loop']) {
    compareRuntimeScalar(`${base}.${name}`, staticClip[name], field(runtimeClip, name));
  }
  const staticStates = Array.isArray(staticClip.statenames) ? staticClip.statenames : [];
  const runtimeStates = runtimeList(field(runtimeClip, 'statenames')).map(runtimeString);
  same(`${base}.statenames.length`, staticStates.length, runtimeStates.length);
  for (let i = 0; i < Math.min(staticStates.length, runtimeStates.length); i += 1) {
    same(`${base}.statenames[${i}]`, staticStates[i], runtimeStates[i]);
  }
  if (runtimeStates.length > 0) same(`${base}.dictionaryKey`, staticStates[0], runtimeEntry.key);

  const staticKeyframes = staticClip.keyframes || {};
  const runtimeKeyframes = dictionaryEntries(field(runtimeClip, 'keyframes'));
  const runtimeKeyframeMap = new Map(runtimeKeyframes.map((entry) => [String(entry.key), entry.value]));
  same(`${base}.keyframes.length`, Object.keys(staticKeyframes).length, runtimeKeyframes.length);
  for (const [key, staticFrame] of Object.entries(staticKeyframes)) {
    const runtimeFrame = runtimeKeyframeMap.get(key);
    same(`${base}.keyframes[${key}].present`, true, runtimeFrame !== undefined);
    if (runtimeFrame !== undefined && !isRuntimeReference(runtimeFrame)) {
      stats.keyframes += 1;
      compareAnimationFrame(`${base}.keyframes[${key}]`, staticFrame, runtimeFrame);
    } else if (isRuntimeReference(runtimeFrame)) {
      stats.skippedRuntimeReferences += 1;
    }
  }
  same(`${base}.offsetPoints.length`, (staticClip.offsetPoints || []).length, runtimeList(field(runtimeClip, 'offsetPoints')).length);
}

const runtimeObjectFrames = dictionaryEntries(field(runtimeActor, 'objectFrames'));
const staticObjectFrames = staticJson.objectFrames || {};
const runtimeObjectFrameMap = new Map(runtimeObjectFrames.map((entry) => [String(entry.key), entry.value]));
same('ActorData.objectFrames.length', Object.keys(staticObjectFrames).length, runtimeObjectFrames.length);
for (const [key, staticFrame] of Object.entries(staticObjectFrames)) {
  const runtimeFrame = runtimeObjectFrameMap.get(key);
  same(`ActorData.objectFrames[${key}].present`, true, runtimeFrame !== undefined);
  if (runtimeFrame !== undefined && !isRuntimeReference(runtimeFrame)) {
    stats.objectFrames += 1;
    compareFrameData(`ActorData.objectFrames[${key}]`, staticFrame, runtimeFrame);
  } else if (isRuntimeReference(runtimeFrame)) {
    stats.skippedRuntimeReferences += 1;
  }
}

const staticKfbHash = sha256(staticKfb);
const runtimeKfbHash = sha256(runtimeKfb);
const byteIdentical = staticKfb.equals(runtimeKfb);
const result = byteIdentical && mismatches.length === 0 ? 'match' : 'mismatch';
const report = {
  schema_version: 1,
  result,
  primary_verification: {
    byte_identical: byteIdentical,
    static_decrypted_kfb: { bytes: staticKfb.length, sha256: staticKfbHash },
    runtime_dump_kfb: { bytes: runtimeKfb.length, sha256: runtimeKfbHash },
  },
  structural_comparison: {
    ...stats,
    mismatches: mismatches.length,
    runtime_capture_class: runtimeCapture.class,
    static_root_type: schema.root_type,
    static_clip_count: staticClips.length,
    runtime_clip_count: runtimeClipEntries.length,
    static_object_frame_count: Object.keys(staticObjectFrames).length,
    runtime_object_frame_count: runtimeObjectFrames.length,
  },
  representation_notes: [
    'Runtime JSON is a reflection-memory dump, while static JSON is schema-decoded semantic data.',
    'Circular/depth-limit reflection markers cannot be compared as values and are counted separately.',
    'Unsafe JSON integers from reflected Int64 fields are counted separately instead of being treated as exact.',
    'FScalar/FVector values are compared against their raw fixed-point integer components.',
  ],
  mismatches,
};

const absoluteReport = path.resolve(reportPath);
fs.writeFileSync(`${absoluteReport}.tmp`, `${JSON.stringify(report, null, 2)}\n`, 'utf8');
fs.renameSync(`${absoluteReport}.tmp`, absoluteReport);
console.log(JSON.stringify(report, null, 2));
process.exit(result === 'match' ? 0 : 1);
