# 新版 KFB 静态解密结果

## 已确认的数据路径

新版 `2854344920.assetbundle` 是标准 `UnityFS`，格式版本 8，`flags=0xC0`。
其中 `0x80` 表示 BlocksInfo 位于文件尾部；格式版本 7 及以上的数据区在
UnityFS 头后按 16 字节对齐。目标 TextAsset 为 `90097_p`。

TextAsset 的 `m_Script` 仍使用下面的资源加密容器：

```text
[0x00..0x03] 4 字节外层头
[0x04..0x13] 16 字节 AES-CTR IV
[0x14..]      AES-256-CTR 密文
```

AES 解密结果为：

```text
[0x00..0x03] LZ4 解压后长度（uint32 little-endian）
[0x04..]      raw LZ4 block
```

LZ4 解压输出就是游戏传给 `KH.ActorDataFileUtil.FromBytes(byte[])` 的完整
明文 KFB。KFB 是 `KFBuffers` 的二进制序列化格式，不存在第二层密码或第二把
密钥；如果需要 JSON/XML，则属于 KFB 反序列化，而不是继续做密码解密。

## 本样本实测

```text
输入 AssetBundle SHA-256:
F7E2F1F99A27CE8D9B303B4A2820F04AE26D024F283B4DEA521046F1166F8B08

TextAsset:             90097_p
加密 m_Script:         20562 bytes
AES IV:                80fa8a3366a90f490353ec44188b83a0
FromBytes 明文 KFB:    91665 bytes
明文 KFB SHA-256:
48C9FAF35D1AF713A1229D8C4FC622ABC223596FB55435B08FCA460A8F38AC05
```

明文开头为：

```text
14 0C 4E 6F 72 6D 61 6C 53 68 61 64 6F 77 ...
```

即字段号 2、wire type 4、长度 12、字符串 `NormalShadow`，与
`KH.ActorData.shadowName` 一致，证明输出已进入 KFB 明文层。

## 使用

工具能自动识别新版尾置 BlocksInfo，并可用 `auto` 自动找到能通过
AES-CTR + 严格 LZ4 校验的 TextAsset：

```powershell
node D:\IDA93\1\逆向\kfb_static_decrypt.js decrypt-bundle `
  D:\IDA93\1\2854344920_new.assetbundle auto `
  D:\IDA93\1\逆向\2854344920_static_plain.kfb `
  --key c49ad87a038d44866c610adff4456008d3d7aafe73db09bbc36ab3be6ae7df0e
```

如需结构预览，可附加：

```text
--wire-json D:\IDA93\1\逆向\2854344920_static_wire.json --max-depth 3
```

Wire 类型为：`0 Variant`、`1 Fixed32`、`2 Fixed64`、`3 Object`、
`4 String`、`5 List`、`6 Dictionary`、`7 Packed`。没有 schema 时，
List/Dictionary 后面的预览只能用于定位；这不影响 `.kfb` 明文字节的完整性。
