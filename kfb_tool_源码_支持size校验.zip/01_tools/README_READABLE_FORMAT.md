﻿# KFB 可编辑 JSON/XML v2 速查

## `@0x` 是什么

旧 JSON 的 `@0x10` 来自 IL2CPP `FieldInfo::getOffset()`，表示 arm64 对象中的内存字段偏移。它不是 KFB 文件偏移；KFB 写回使用 Schema 的字段 tag、声明类型和多态 type ID。

`runtime-readable v2` 默认删除这些偏移，但保留显示类型：

```json
{
  "KH.ShowMsgTextArg": {
    "Int32 scriptType": 1173,
    "Int32 argInt": 0,
    "String argStr": "",
    "Boolean CanBothSee": false,
    "String Msg": null
  }
}
```

继承链出现同名字段时使用声明类限定名，例如：

```json
{
  "Boolean AOEScriptArg.ignoreInvincible": true,
  "Boolean AreaTestScriptArg.ignoreInvincible": false
}
```

`key`、`motionFrameIndex`、`scriptIndex` 不写入 KFB，v2 不再输出。旧版带 `@0x` 的 v1 JSON 仍可直接传给 `encode`/`encode-bundle`。

## 解密

```powershell
node .\kfb_static_decrypt.js decode-bundle `
  ..\01_original_assets\3524447070_original_UnityKH1FS.assetbundle `
  auto ..\work\90381 `
  --key adc524d284ee93d118853c9b341c49bc321a3754ec1b084e627d65acd69f8ba9 `
  --schema .\kfb_schema.json --dump-layout .\kfb_dump_layout.json
```

输出：

```text
work/90381.json          runtime-readable v2 JSON（推荐编辑）
work/90381.xml           AnimationData XML
work/90381.semantic.json KFB 语义 JSON
```

`kfb_dump_layout.json` 只用于兼容 v1 和补充显示类型，不再要求用户填写或修改偏移。

## 从 Schema 复制模板

`kfb_schema.json` 的全部 1145 个 `types[]` 记录均包含：

```text
template_json
template_xml
template_status
template_error
```

`KH.ShowMsgTextArg` 的 JSON 模板把 `Msg` 默认保留为游戏真实值 `null`。使用时将它改为字符串并把整个 `{ "KH.ShowMsgTextArg": ... }` 对象追加到 `idle -> keyframes -> 0 -> frameData -> scriptDatas`。

XML 模板：

```xml
<KHScriptData kfbType="KH.ShowMsgTextArg" scriptType="1173" argInt="0" argStr="" CanBothSee="False">
  <Field name="Msg" declaredType="System.String">
    <Null />
  </Field>
</KHScriptData>
```

设置文字时把 `<Null />` 替换为：

```xml
<String>要显示的文字</String>
```

脚本模板使用 `<KHScriptData>`；其他类型使用 `<KFBObject kfbType="...">`。静态 XML 写回器支持 `Field/Null/List/Dictionary/KFBObject` 通用模板节点。

## 写回 UnityFS

```powershell
node .\kfb_static_decrypt.js encode-bundle `
  ..\01_original_assets\3524447070_original_UnityKH1FS.assetbundle `
  auto ..\04_modified_output\90381_showmsg_area_v2.json `
  ..\04_modified_output\90381_showmsg_area_v2_UnityFS.assetbundle `
  --key adc524d284ee93d118853c9b341c49bc321a3754ec1b084e627d65acd69f8ba9 `
  --schema .\kfb_schema.json --dump-layout .\kfb_dump_layout.json `
  --crc 0xD212CB5E --unityfs
```

写回器会重新打开输出包，校验 KFB 语义回环、未知字段覆盖和 CRC。
