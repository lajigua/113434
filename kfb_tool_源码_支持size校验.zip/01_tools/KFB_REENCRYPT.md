# KFB 解密、编辑与回写

## Python 交互界面

安装 Python 3.9+ 和 Node.js 后，双击或执行：

```powershell
python .\kfb_ab_gui.py
```

界面依次选择原始 AssetBundle、粘贴 64 位 AES Key，然后选择“解密”或“修改后回加密”。回加密时再选择修改后的 JSON/XML、输出文件和可选 CRC；默认输出标准 UnityFS。

如果系统没有 Tk 图形组件，可使用命令行交互模式：

```powershell
python .\kfb_ab_gui.py --console
```

Python 脚本会自动使用同目录下的 `kfb_static_decrypt.js`、`kfb_schema.json` 和 `kfb_dump_layout.json`，并在日志中隐藏完整 Key。
## 推荐输入格式

`decode` 和 `decode-bundle` 默认输出 `KH.ActorData runtime-readable v2`：字段键保留类型、删除 IL2CPP 内存偏移。

```json
{
  "KH.TSToWalkableScriptArg": {
    "Int32 scriptType": 1051,
    "Int32 argInt": 0,
    "String argStr": "",
    "Boolean ignoreYSetZero": false
  }
}
```

旧 v1 JSON 中的 `Int32 scriptType @0x10` 等键继续兼容。v2 不再输出 `key`、`motionFrameIndex`、`scriptIndex`，因为它们不是 KFB 字段。

## 解密 AssetBundle

```powershell
node .\kfb_static_decrypt.js decode-bundle `
  <输入.assetbundle> auto <输出基础名> `
  --key <64位十六进制AES密钥> `
  --schema .\kfb_schema.json `
  --dump-layout .\kfb_dump_layout.json
```

生成 `<输出基础名>.json`、`.xml`、`.semantic.json`。

## 修改并写回 KFB

```powershell
node .\kfb_static_decrypt.js encode `
  <可编辑.json|可编辑.xml|semantic.json> <输出.kfb> `
  --schema .\kfb_schema.json `
  --dump-layout .\kfb_dump_layout.json
```

## 修改并写回 AssetBundle

```powershell
node .\kfb_static_decrypt.js encode-bundle `
  <原始.assetbundle> auto <可编辑.json|可编辑.xml> <输出.assetbundle> `
  --key <64位十六进制AES密钥> `
  --schema .\kfb_schema.json `
  --dump-layout .\kfb_dump_layout.json `
  --crc <原包CRC> --unityfs
```

`--unityfs` 输出标准 UnityFS；工具会执行 KFB 编码、LZ4、AES-256-CTR、TextAsset 替换、UnityFS 重建、CRC 修复和重开验证。

## size 校验（游戏更新后）：--match-size

新版游戏要求重打包后的 AssetBundle 与原包**字节数完全一致**。加 `--match-size`：

```powershell
node .\kfb_static_decrypt.js encode-bundle `
  <原始.assetbundle> auto <可编辑.json> <输出.assetbundle> `
  --key <64位十六进制AES密钥> `
  --schema .\kfb_schema.json --dump-layout .\kfb_dump_layout.json `
  --match-size
```

行为：
1. 内层容器改用最优解析 LZ4（压缩率对齐 LZ4HC），不再是 literal-only；
2. UnityFS 数据块分段压缩：密文区间原样存放（避免二次压缩膨胀），元数据用 LZ4HC；
   放不下时自动换 LZMA（type 1，Unity 引擎原生支持）压缩元数据块；
3. 外壳优先保留 KH 壳，必要时退回裸 UnityFS（引擎可直接读取）；
4. 末尾补 0x00 凑到与原包完全一致的字节数；
5. 该模式下默认跳过 CRC 修复（修复字节白占体积）；显式传 `--crc` 仍会修复。

所有候选体积和最终选择见输出 JSON 的 `matchSize` 字段。
LZMA 依赖同目录的 `vendor_lzma.js`（MIT，来自 LZMA-JS），请勿删除。

## 模板

当前 Schema 的每个类型都有 `template_json` 和 `template_xml`。脚本类模板可直接追加到 `scriptDatas`；非脚本类模板使用通用 `<KFBObject>` 结构。详细格式见 `README_READABLE_FORMAT.md`。
