#!/usr/bin/env python3
"""
Unity AssetBundle CRC 修复工具

目标 CRC = int(原文件名) & 0xFFFFFFFF
例如: 2083474168.assetbundle → 0x7C2F4AF8

用法:
  python3 bundle_fix.py --name <原文件名(十进制)> <修改后文件> [输出文件]
  python3 bundle_fix.py --crc 0x7C2F4AF8 <修改后文件> [输出文件]
  python3 bundle_fix.py <修改后文件>                 # 显示CRC
"""

import sys
import struct
import zlib
import lz4.block

KEY_0 = b"X@85Pq!6v$lCt7UYsihH3!cPb1P71bo4lX59FXqY!VO$YiYsu!Keu3aVZwi5on5l"


def xor_data(data, key):
    return bytes(data[i] ^ key[i % len(key)] for i in range(len(data)))


def decompress_bi(bi_compressed, uncomp_bi):
    """解压 BlockInfo → (header, count, entries_list, raw_bi)"""
    try:
        bi = lz4.block.decompress(bi_compressed, uncompressed_size=uncomp_bi)
    except:
        bi = lz4.block.decompress(xor_data(bi_compressed, KEY_0),
                                  uncompressed_size=uncomp_bi)
    header = bi[:16]
    count = struct.unpack('>I', bi[16:20])[0]
    entries = []
    pos = 20
    for _ in range(count):
        u = struct.unpack('>I', bi[pos:pos+4])[0]
        c = struct.unpack('>I', bi[pos+4:pos+8])[0]
        f = struct.unpack('>H', bi[pos+8:pos+10])[0]
        entries.append((u, c, f))
        pos += 10
    return header, count, entries, bi


def decompress_blocks(data_area, entries):
    """按 entries 解压数据块"""
    blocks = []
    off = 14
    for u, c, f in entries:
        chunk = data_area[off:off+c]
        dst = bytearray(); si = 0
        while si < len(chunk) and len(dst) < u:
            token = chunk[si]; si += 1
            lit_len = token >> 4
            if lit_len == 15:
                while si < len(chunk) and len(dst) < u:
                    b = chunk[si]; si += 1; lit_len += b
                    if b < 255: break
            if lit_len > 0:
                end = min(si + lit_len, len(chunk))
                dst.extend(chunk[si:end]); si = end
            if len(dst) >= u: break
            if si >= len(chunk): break
            if si + 1 >= len(chunk): break
            offset = chunk[si] | (chunk[si+1] << 8); si += 2
            if offset == 0 or offset > len(dst): break
            match_len = (token & 0xF) + 4
            if (token & 0xF) == 15:
                while si < len(chunk) and len(dst) < u:
                    b = chunk[si]; si += 1; match_len += b
                    if b < 255: break
            pos = len(dst) - offset
            if pos < 0: break
            for _ in range(match_len):
                if len(dst) >= u: break
                if pos >= len(dst): break
                dst.append(dst[pos]); pos += 1
        blocks.append(bytes(dst))
        off += c
    return blocks


def crc32_append_fix(data, target_crc):
    """末尾追加4字节使 CRC32(data) == target_crc"""
    table = []
    for i in range(256):
        c = i
        for _ in range(8):
            c = (c >> 1) ^ 0xEDB88320 if c & 1 else c >> 1
        table.append(c)

    cur = bytearray(data + b'\x00\x00\x00\x00')
    cur_crc = zlib.crc32(cur) & 0xFFFFFFFF
    delta = target_crc ^ cur_crc

    n = 32; matrix = [[0]*n for _ in range(n)]
    for bit in range(n):
        test = bytearray(4); test[bit//8] = 1 << (bit%8)
        cw = 0xFFFFFFFF
        for b in test: cw = table[(cw^b)&0xFF]^(cw>>8)
        cz = 0xFFFFFFFF
        for _ in range(4): cz = table[(cz^0)&0xFF]^(cz>>8)
        diff = cw ^ cz
        for i in range(n):
            if diff & (1<<i): matrix[i][bit] = 1

    aug = [row+[0] for row in matrix]
    for i in range(n):
        if delta & (1<<i): aug[i][n] = 1

    res = [0]*n
    for col in range(n):
        p = -1
        for row in range(col, n):
            if aug[row][col]: p = row; break
        if p == -1: continue
        aug[col], aug[p] = aug[p], aug[col]
        for row in range(n):
            if row != col and aug[row][col]:
                for j in range(n+1): aug[row][j] ^= aug[col][j]

    for i in range(n):
        if aug[i][i]: res[i] = aug[i][n]

    fix = bytearray(4)
    for bit in range(n):
        if res[bit]: fix[bit//8] |= 1<<(bit%8)
    return bytes(bytearray(data+fix)), bytes(fix)


def parse_file(filepath):
    """解析 UnityFS/KHF 文件 → (header, data_area, bi_compressed, uncomp_bi, meta_off)"""
    with open(filepath, 'rb') as f:
        data = f.read()

    if data[:7] == b'UnityFS':
        meta_off, hdr_end = 0x1E, 0x32
    elif data[:10] == b'UnityKHFS\x00':
        meta_off, hdr_end = 0x20, 0x34
    else:
        raise ValueError(f"Unknown format: {data[:16]}")

    comp_bi = struct.unpack('>I', data[meta_off+8:meta_off+12])[0]
    uncomp_bi = struct.unpack('>I', data[meta_off+12:meta_off+16])[0]
    flags = struct.unpack('>I', data[meta_off+16:meta_off+20])[0]

    if flags & 0x40:
        bi_compressed = data[len(data)-comp_bi:]
        data_area = data[hdr_end:len(data)-comp_bi]
    else:
        bi_compressed = data[hdr_end:hdr_end+comp_bi]
        data_area = data[hdr_end+comp_bi:]

    return data[:hdr_end], data_area, bi_compressed, uncomp_bi, meta_off


def fix_bundle(mod_path, target_crc, output_path):
    """修复修改文件的 CRC 到 target_crc"""
    print(f"\n{'='*60}")
    print(f"AssetBundle CRC 修复")
    print(f"{'='*60}")
    print(f"修改文件: {mod_path}")
    print(f"目标 CRC: 0x{target_crc:08X}")

    hdr, data, bi_comp, uncomp_bi, meta_off = parse_file(mod_path)
    _, count, entries, raw_bi = decompress_bi(bi_comp, uncomp_bi)
    blocks = decompress_blocks(data, entries)
    all_dec = b''.join(blocks)
    cur_crc = zlib.crc32(all_dec) & 0xFFFFFFFF

    print(f"块数: {count}")
    print(f"解压: {len(all_dec)} bytes")
    print(f"当前 CRC: 0x{cur_crc:08X}")

    if cur_crc == target_crc:
        print("✓ 已匹配, 无需修复")
        return

    # CRC fixup
    fixed_all, fix_bytes = crc32_append_fix(all_dec, target_crc)
    print(f"修复字节: {fix_bytes.hex()}")

    # 更新最后一块
    new_last_decomp = blocks[-1] + fix_bytes
    new_last_comp = lz4.block.compress(new_last_decomp, mode="high_compression",
                                       compression=12, store_size=False)
    old_last_u, old_last_c, _ = entries[-1]
    print(f"最后一块: uncomp {old_last_u}→{len(new_last_decomp)}, comp {old_last_c}→{len(new_last_comp)}")

    # 更新 BlockInfo
    new_bi = bytearray(raw_bi)
    last_off = 20 + (count - 1) * 10
    struct.pack_into('>I', new_bi, last_off, len(new_last_decomp))
    struct.pack_into('>I', new_bi, last_off + 4, len(new_last_comp))
    new_bi_comp = lz4.block.compress(bytes(new_bi), mode="high_compression",
                                     compression=12, store_size=False)

    # 重建数据区 (不补齐, 直接改大小)
    cum = 14
    new_data = data[:14]
    for u, c, f in entries[:-1]:
        new_data += data[cum:cum+c]; cum += c
    cum += old_last_c
    new_data += new_last_comp + data[cum:]

    # 重建头部 (更新 compBI + dataSize)
    hdr_end = meta_off + 20
    hdr = bytearray(hdr[:hdr_end])
    struct.pack_into('>I', hdr, meta_off+8, len(new_bi_comp))

    out = bytearray(bytes(hdr) + new_data + new_bi_comp)
    struct.pack_into('>Q', out, meta_off, len(out))  # 更新 dataSize

    with open(output_path, 'wb') as f:
        f.write(out)

    print(f"\n输出: {output_path} ({len(out)} bytes, 原{hdr_end+len(data)+len(bi_comp)})")

    # 验证
    with open(output_path, 'rb') as f: vfy = f.read()
    _, _, vfy_entries, _ = decompress_bi(vfy[len(vfy)-len(new_bi_comp):], uncomp_bi)
    vfy_blocks = decompress_blocks(vfy[hdr_end:len(vfy)-len(new_bi_comp)], vfy_entries)
    vfy_crc = zlib.crc32(b''.join(vfy_blocks)) & 0xFFFFFFFF
    print(f"验证 CRC: 0x{vfy_crc:08X} {'✓' if vfy_crc == target_crc else '✗'}")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    args = sys.argv[1:]
    target_crc = None
    mod_file = None
    out_file = None

    i = 0
    while i < len(args):
        if args[i] == '--name':
            name = args[i+1].split('.')[0]  # 去掉扩展名
            target_crc = int(name) & 0xFFFFFFFF
            i += 2
        elif args[i] == '--crc':
            target_crc = int(args[i+1], 16)
            i += 2
        elif mod_file is None:
            mod_file = args[i]; i += 1
        elif out_file is None:
            out_file = args[i]; i += 1
        else:
            i += 1

    if mod_file is None:
        print("错误: 需要指定修改文件")
        sys.exit(1)

    if out_file is None:
        out_file = mod_file + ".fixed"

    if target_crc is not None:
        fix_bundle(mod_file, target_crc, out_file)
    else:
        # 仅显示 CRC
        hdr, data, bi_comp, uncomp_bi, _ = parse_file(mod_file)
        _, count, entries, _ = decompress_bi(bi_comp, uncomp_bi)
        blocks = decompress_blocks(data, entries)
        all_dec = b''.join(blocks)
        print(f"文件: {mod_file}")
        print(f"块数: {count}, 解压: {len(all_dec)} bytes")
        print(f"CRC32: 0x{zlib.crc32(all_dec) & 0xFFFFFFFF:08X}")
        for i, (u, c, f) in enumerate(entries):
            print(f"  [{i}] uncomp={u} comp={c} flags=0x{f:04x}")


if __name__ == '__main__':
    main()
