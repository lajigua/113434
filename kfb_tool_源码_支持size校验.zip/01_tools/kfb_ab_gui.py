#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Interactive wrapper for KFB AssetBundle decode and re-encryption."""

from __future__ import annotations

import getpass
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
from pathlib import Path
from typing import Callable, Iterable


SCRIPT_DIR = Path(__file__).resolve().parent
TOOL = SCRIPT_DIR / "kfb_static_decrypt.js"
SCHEMA = SCRIPT_DIR / "kfb_schema.json"
LAYOUT = SCRIPT_DIR / "kfb_dump_layout.json"
KEY_RE = re.compile(r"^[0-9a-fA-F]{64}$")


def setup_console_encoding() -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (OSError, ValueError):
                pass


def clean_path(value: str) -> Path:
    return Path(value.strip().strip('"').strip("'")).expanduser().resolve()


def find_node() -> str:
    node = shutil.which("node") or shutil.which("node.exe")
    if not node:
        raise RuntimeError("没有找到 Node.js，请先安装 Node.js 并把 node 加入 PATH。")
    return node


def check_assets() -> None:
    missing = [str(item) for item in (TOOL, SCHEMA, LAYOUT) if not item.is_file()]
    if missing:
        raise RuntimeError("缺少工具文件：\n" + "\n".join(missing))


def validate_key(key: str) -> str:
    key = key.strip()
    if not KEY_RE.fullmatch(key):
        raise ValueError("AES-256 Key 必须是 64 位十六进制字符串。")
    return key.lower()


def default_decode_base(bundle: Path) -> Path:
    return bundle.with_name(f"{bundle.stem}_decrypted")


def default_modified_bundle(bundle: Path) -> Path:
    return bundle.with_name(f"{bundle.stem}_modified_UnityFS.assetbundle")


def build_decode_command(bundle: Path, key: str, output_base: Path) -> list[str]:
    return [
        find_node(), str(TOOL), "decode-bundle", str(bundle), "auto", str(output_base),
        "--key", validate_key(key), "--schema", str(SCHEMA), "--dump-layout", str(LAYOUT),
    ]


def build_encode_command(
    bundle: Path,
    key: str,
    readable: Path,
    output_bundle: Path,
    crc: str = "",
    unityfs: bool = True,
    match_size: bool = True,
) -> list[str]:
    if not readable.is_file():
        raise ValueError(f"修改文件不存在：{readable}")
    if readable.suffix.lower() not in {".json", ".xml"}:
        raise ValueError("修改文件必须是 .json 或 .xml。")
    if output_bundle == bundle:
        raise ValueError("输出 AssetBundle 不能覆盖原始 AssetBundle。")
    command = [
        find_node(), str(TOOL), "encode-bundle", str(bundle), "auto", str(readable),
        str(output_bundle), "--key", validate_key(key), "--schema", str(SCHEMA),
        "--dump-layout", str(LAYOUT),
    ]
    if crc.strip():
        if not re.fullmatch(r"(?:0x[0-9a-fA-F]{1,8}|\d+)", crc.strip()):
            raise ValueError("CRC 必须是 0x 开头的十六进制或十进制整数。")
        command.extend(["--crc", crc.strip()])
    if unityfs:
        command.append("--unityfs")
    if match_size:
        # 新版 size 校验：输出必须与原包字节数一致（LZ4HC/LZMA 重压 + 补零对齐）
        command.append("--match-size")
    return command


def masked_command(command: Iterable[str]) -> str:
    parts = list(command)
    for index, value in enumerate(parts[:-1]):
        if value == "--key":
            key = parts[index + 1]
            parts[index + 1] = f"{key[:8]}...{key[-8:]}"
    return subprocess.list2cmdline(parts)


def run_process(command: list[str], emit: Callable[[str], None] = print) -> int:
    emit("执行命令：")
    emit(masked_command(command))
    emit("")
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=creationflags,
    )
    assert process.stdout is not None
    for line in process.stdout:
        emit(line.rstrip("\r\n"))
    return process.wait()


def console_main() -> int:
    setup_console_encoding()
    check_assets()
    print("KFB AssetBundle 解密/回加密")
    bundle = clean_path(input("1. 输入或拖入 AssetBundle 路径："))
    if not bundle.is_file():
        raise ValueError(f"AssetBundle 不存在：{bundle}")
    try:
        key = getpass.getpass("2. 输入 AES-256 Key（64 位十六进制）：")
    except Exception:
        key = input("2. 输入 AES-256 Key（64 位十六进制）：")
    key = validate_key(key)
    operation = input("3. 选择操作：[1] 解密  [2] 修改后回加密：").strip()

    if operation == "1":
        default = default_decode_base(bundle)
        entered = input(f"输出文件基名（回车使用 {default}）：").strip()
        output_base = clean_path(entered) if entered else default
        output_base.parent.mkdir(parents=True, exist_ok=True)
        command = build_decode_command(bundle, key, output_base)
        code = run_process(command)
        if code == 0:
            print(f"\n解密完成：{output_base}.json")
        return code

    if operation == "2":
        readable = clean_path(input("选择修改后的 JSON/XML 路径："))
        default = default_modified_bundle(bundle)
        entered = input(f"输出 AssetBundle（回车使用 {default}）：").strip()
        output_bundle = clean_path(entered) if entered else default
        crc = input("CRC（可留空自动处理，例如 0xD212CB5E）：").strip()
        unityfs = input("输出标准 UnityFS？[Y/n]：").strip().lower() not in {"n", "no"}
        match_size = input("对齐原包大小（size 校验需要）？[Y/n]：").strip().lower() not in {"n", "no"}
        output_bundle.parent.mkdir(parents=True, exist_ok=True)
        command = build_encode_command(bundle, key, readable, output_bundle, crc, unityfs, match_size)
        code = run_process(command)
        if code == 0:
            print(f"\n回加密完成：{output_bundle}")
        return code

    raise ValueError("操作必须选择 1 或 2。")


def gui_main() -> int:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from tkinter.scrolledtext import ScrolledText

    check_assets()
    root = tk.Tk()
    root.title("KFB AssetBundle 解密 / 回加密")
    root.geometry("860x650")
    root.minsize(760, 560)

    operation = tk.StringVar(value="decrypt")
    bundle_var = tk.StringVar()
    key_var = tk.StringVar()
    show_key_var = tk.BooleanVar(value=False)
    readable_var = tk.StringVar()
    output_var = tk.StringVar()
    crc_var = tk.StringVar()
    unityfs_var = tk.BooleanVar(value=True)
    match_size_var = tk.BooleanVar(value=True)
    events: queue.Queue[tuple[str, object]] = queue.Queue()

    frame = ttk.Frame(root, padding=12)
    frame.pack(fill="both", expand=True)
    frame.columnconfigure(1, weight=1)

    def choose_bundle() -> None:
        selected = filedialog.askopenfilename(
            title="选择原始 AssetBundle",
            filetypes=[("AssetBundle", "*.assetbundle"), ("所有文件", "*.*")],
        )
        if selected:
            bundle_var.set(selected)
            bundle = clean_path(selected)
            output_var.set(str(default_decode_base(bundle) if operation.get() == "decrypt"
                               else default_modified_bundle(bundle)))

    def choose_readable() -> None:
        selected = filedialog.askopenfilename(
            title="选择修改后的 JSON/XML",
            filetypes=[("KFB 可编辑文件", "*.json *.xml"), ("JSON", "*.json"),
                       ("XML", "*.xml"), ("所有文件", "*.*")],
        )
        if selected:
            readable_var.set(selected)

    def choose_output() -> None:
        bundle_text = bundle_var.get().strip()
        bundle = clean_path(bundle_text) if bundle_text else Path.cwd() / "output.assetbundle"
        if operation.get() == "decrypt":
            selected = filedialog.askdirectory(title="选择解密输出目录")
            if selected:
                output_var.set(str(Path(selected) / f"{bundle.stem}_decrypted"))
        else:
            selected = filedialog.asksaveasfilename(
                title="保存修改后的 AssetBundle",
                defaultextension=".assetbundle",
                initialfile=f"{bundle.stem}_modified_UnityFS.assetbundle",
                filetypes=[("AssetBundle", "*.assetbundle"), ("所有文件", "*.*")],
            )
            if selected:
                output_var.set(selected)

    def paste_key() -> None:
        try:
            key_var.set(root.clipboard_get().strip())
        except tk.TclError:
            messagebox.showerror("粘贴失败", "剪贴板中没有可用文本。")

    def refresh_operation() -> None:
        encrypting = operation.get() == "encrypt"
        readable_entry.configure(state="normal" if encrypting else "disabled")
        readable_button.configure(state="normal" if encrypting else "disabled")
        crc_entry.configure(state="normal" if encrypting else "disabled")
        unityfs_check.configure(state="normal" if encrypting else "disabled")
        output_label.configure(text="输出 AssetBundle" if encrypting else "解密输出基名")
        if bundle_var.get().strip():
            bundle = clean_path(bundle_var.get())
            output_var.set(str(default_modified_bundle(bundle) if encrypting
                               else default_decode_base(bundle)))

    ttk.Label(frame, text="原始 AssetBundle").grid(row=0, column=0, sticky="w", pady=5)
    ttk.Entry(frame, textvariable=bundle_var).grid(row=0, column=1, sticky="ew", padx=8)
    ttk.Button(frame, text="选择文件", command=choose_bundle).grid(row=0, column=2)

    ttk.Label(frame, text="AES-256 Key").grid(row=1, column=0, sticky="w", pady=5)
    key_entry = ttk.Entry(frame, textvariable=key_var, show="*")
    key_entry.grid(row=1, column=1, sticky="ew", padx=8)
    key_buttons = ttk.Frame(frame)
    key_buttons.grid(row=1, column=2, sticky="e")
    ttk.Button(key_buttons, text="粘贴", command=paste_key).pack(side="left")
    ttk.Checkbutton(
        key_buttons,
        text="显示",
        variable=show_key_var,
        command=lambda: key_entry.configure(show="" if show_key_var.get() else "*"),
    ).pack(side="left", padx=(6, 0))

    ttk.Label(frame, text="操作").grid(row=2, column=0, sticky="w", pady=5)
    operation_frame = ttk.Frame(frame)
    operation_frame.grid(row=2, column=1, sticky="w", padx=8)
    ttk.Radiobutton(operation_frame, text="解密 AB → JSON/XML", variable=operation,
                    value="decrypt", command=refresh_operation).pack(side="left")
    ttk.Radiobutton(operation_frame, text="修改后回加密", variable=operation,
                    value="encrypt", command=refresh_operation).pack(side="left", padx=18)

    ttk.Label(frame, text="修改后的 JSON/XML").grid(row=3, column=0, sticky="w", pady=5)
    readable_entry = ttk.Entry(frame, textvariable=readable_var)
    readable_entry.grid(row=3, column=1, sticky="ew", padx=8)
    readable_button = ttk.Button(frame, text="选择文件", command=choose_readable)
    readable_button.grid(row=3, column=2)

    output_label = ttk.Label(frame, text="解密输出基名")
    output_label.grid(row=4, column=0, sticky="w", pady=5)
    ttk.Entry(frame, textvariable=output_var).grid(row=4, column=1, sticky="ew", padx=8)
    ttk.Button(frame, text="选择位置", command=choose_output).grid(row=4, column=2)

    ttk.Label(frame, text="CRC（可留空）").grid(row=5, column=0, sticky="w", pady=5)
    crc_entry = ttk.Entry(frame, textvariable=crc_var)
    crc_entry.grid(row=5, column=1, sticky="ew", padx=8)
    unityfs_check = ttk.Checkbutton(frame, text="输出标准 UnityFS", variable=unityfs_var)
    unityfs_check.grid(row=5, column=2, sticky="w")
    match_size_check = ttk.Checkbutton(
        frame, text="对齐原包大小（size 校验）", variable=match_size_var
    )
    match_size_check.grid(row=6, column=1, sticky="w")

    log = ScrolledText(frame, height=21, wrap="word", state="disabled")
    log.grid(row=7, column=0, columnspan=3, sticky="nsew", pady=(12, 0))
    frame.rowconfigure(7, weight=1)

    def append_log(text: str) -> None:
        log.configure(state="normal")
        log.insert("end", text + "\n")
        log.see("end")
        log.configure(state="disabled")

    def worker(command: list[str], success_path: Path) -> None:
        try:
            code = run_process(command, lambda line: events.put(("log", line)))
            events.put(("done", (code, success_path)))
        except Exception as error:  # UI must report subprocess and filesystem errors.
            events.put(("error", str(error)))

    def run_clicked() -> None:
        try:
            bundle = clean_path(bundle_var.get())
            if not bundle.is_file():
                raise ValueError(f"AssetBundle 不存在：{bundle}")
            key = validate_key(key_var.get())
            output = clean_path(output_var.get())
            output.parent.mkdir(parents=True, exist_ok=True)
            if operation.get() == "decrypt":
                command = build_decode_command(bundle, key, output)
                success_path = Path(str(output) + ".json")
            else:
                readable = clean_path(readable_var.get())
                command = build_encode_command(
                    bundle, key, readable, output, crc_var.get(), unityfs_var.get(),
                    match_size_var.get()
                )
                success_path = output
        except Exception as error:
            messagebox.showerror("参数错误", str(error))
            return
        log.configure(state="normal")
        log.delete("1.0", "end")
        log.configure(state="disabled")
        run_button.configure(state="disabled")
        threading.Thread(target=worker, args=(command, success_path), daemon=True).start()

    def poll_events() -> None:
        try:
            while True:
                kind, payload = events.get_nowait()
                if kind == "log":
                    append_log(str(payload))
                elif kind == "done":
                    code, success_path = payload  # type: ignore[misc]
                    run_button.configure(state="normal")
                    append_log(f"\n退出状态：{code}")
                    if code == 0:
                        messagebox.showinfo("完成", f"处理成功：\n{success_path}")
                    else:
                        messagebox.showerror("处理失败", f"Node 工具退出状态：{code}")
                elif kind == "error":
                    run_button.configure(state="normal")
                    append_log(f"ERROR: {payload}")
                    messagebox.showerror("执行失败", str(payload))
        except queue.Empty:
            pass
        root.after(100, poll_events)

    run_button = ttk.Button(frame, text="开始处理", command=run_clicked)
    run_button.grid(row=6, column=0, columnspan=3, pady=(12, 0), ipadx=30, ipady=4)
    refresh_operation()
    root.after(100, poll_events)
    root.mainloop()
    return 0


def main() -> int:
    setup_console_encoding()
    if "--console" in sys.argv:
        return console_main()
    try:
        return gui_main()
    except (ImportError, RuntimeError) as error:
        print(f"GUI 启动失败，切换到命令行模式：{error}", file=sys.stderr)
        return console_main()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, RuntimeError, OSError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(2)
